// Fleet bot: numbers and information first, then size and control.
//
// Every dragon runs its own copy of this program and shares nothing but sonar,
// so the "fleet" behaviour is emergent: each dragon keeps a persistent model of
// the map, tells teammates what it learns, and makes decisions that stay
// consistent with what the others are likely to decide from the same facts.
//
// Queen update: dragons 0 and 1 are the two queens, and after round 500 the
// longer living queen wins. Our queen is the permanent leader: it never makes
// optional splits, takes no avoidable risk, gets first pick of pearls and is
// what the feeders feed. The enemy queen is worth any one of our other dragons.
// A dragon of length L moves ceil(L/4) steps a turn for free, so sprints are
// planned for pearls, escapes and queen kills.
//
// Per turn (strategy section 20):
//   1. read the 7x7 window into the world model (kelp, portals, pearls, timers)
//   2. read sonar: teammate status, pearls, portals, kelp, enemies, dangers
//   3. infer map symmetry and mirror everything learned onto the other half
//   4. estimate opponent density, pick phase / mode / leaders
//   5. choose one action: survival split, attack, feed, split, or best move
//   6. send four sonars (N, E, S, W) with the most useful facts

#include "helper.hpp"

#include <algorithm>
#include <array>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace unswbc;

// ---------------------------------------------------------------------------
// Tunables (override with -D for local experiments)
// ---------------------------------------------------------------------------
#ifndef EARLY_SPLIT_ROUNDS
#define EARLY_SPLIT_ROUNDS 150 // "X": rounds of aggressive splitting (section 2)
#endif
#ifndef EARLY_SPLIT_MIN_LEN
#define EARLY_SPLIT_MIN_LEN 4 // split as soon as length reaches this (section 2)
#endif
#ifndef LEADER_COUNT
#define LEADER_COUNT 3 // leader dragons in the growth phase (section 11)
#endif
#ifndef PRESERVE_SPLIT_LEN
#define PRESERVE_SPLIT_LEN 8 // non-leaders split at this length to keep numbers
#endif
#ifndef FEED_WINDOW
#define FEED_WINDOW 50 // last rounds in which farming may sacrifice feeders
#endif
#ifndef SPLIT_DENSITY
#define SPLIT_DENSITY 32 // at most one dragon per this many tiles (small maps get crowded)
#endif
#ifndef TRANS_SHIFT
#define TRANS_SHIFT 100 // leader phase starts this much earlier than the section-12 table (tuned)
#endif
#ifndef QUEEN_SEED_UNITS
#define QUEEN_SEED_UNITS 3 // the queen may split off 2 only while the team is this small
#endif
#ifndef HUNT_QUEEN_RANGE
#define HUNT_QUEEN_RANGE 14 // non-queens within this path distance chase the enemy queen
#endif
#ifndef MAX_SPRINT
#define MAX_SPRINT 3 // free steps planned per turn (vision radius is 3)
#endif
#ifndef SURV_NODE_CAP
#define SURV_NODE_CAP 20000 // node budget of the queen's survival search
#endif
#ifndef THREAT_PEN
#define THREAT_PEN 9000 // non-leader stepping next to an enemy head
#endif
#ifndef DIVE_MIN_GAIN
#define DIVE_MIN_GAIN 1 // net segments a dead-end dive must win (pearls eaten minus the 2 left behind)
#endif
#ifndef DIVE_DEPTH
#define DIVE_DEPTH 12 // moves the dive search looks ahead
#endif
#ifndef DIVE_NODE_CAP
#define DIVE_NODE_CAP 4000 // node budget per dive search
#endif
#ifndef EXPANSION
#define EXPANSION 1 // numbers first: everyone (queen included) splits from round 0 up to a denser cap
#endif
#ifndef EXP_DENSITY
#define EXP_DENSITY 12 // expansion cap: one dragon per this many tiles (64 at most)
#endif
#ifndef EXP_END
#define EXP_END 350 // after this round the normal SPLIT_DENSITY cap applies again
#endif
#ifndef QUEEN_GROW_ROUND
#define QUEEN_GROW_ROUND 225 // enemy queen still alive by now: our queen stops splitting and grows
#endif
#ifndef FEED_ONLY_IF_CONTEST
#define FEED_ONLY_IF_CONTEST 1 // no endgame feeding once the enemy queen is dead (ours just has to live)
#endif
#ifndef SURV_UNKNOWN_SAFE
#define SURV_UNKNOWN_SAFE 0 // 1: queen survival search stops at an unexplored edge and calls it safe (old)
#endif
#ifndef QUEEN_THREAT_MAP
#define QUEEN_THREAT_MAP 1 // queen judges enemy reach by path distance (kelp, bodies), sonar reports included
#endif
#ifndef PAID_REACH
#define PAID_REACH 1 // enemy reach includes paid sprint steps (one segment each, down to length 2)
#endif
#ifndef PAID_REACH_CAP
#define PAID_REACH_CAP 24 // longest enemy sprint considered
#endif
#ifndef PAID_THREAT_PEN
#define PAID_THREAT_PEN 200000 // (QUEEN_HARD_THREAT 0) queen ending where an enemy needs k paid steps: PEN / k
#endif
#ifndef QUEEN_HARD_THREAT
#define QUEEN_HARD_THREAT 1 // any cell an enemy can reach with free + paid steps is near-forbidden for the queen
#endif
#ifndef HARD_THREAT_PEN
#define HARD_THREAT_PEN 1200000 // queen ending within an enemy's paid sprint reach (a known dead end costs 1e6)
#endif
#ifndef QUEEN_TRAP_PEN
#define QUEEN_TRAP_PEN 2500000 // queen move with no way out (certain death) must cost more than a mere threat
#endif
#ifndef THREAT_EXTRA_ATTACKER
#define THREAT_EXTRA_ATTACKER 300000 // per additional enemy that can reach the cell
#endif
#ifndef QUEEN_MARGIN
#define QUEEN_MARGIN 4 // steps beyond an enemy's reach the queen still prefers to widen
#endif
#ifndef QUEEN_MARGIN_PEN
#define QUEEN_MARGIN_PEN 20000 // per step of margin missing
#endif
#ifndef ENEMY_LEN_MEMORY
#define ENEMY_LEN_MEMORY 1 // enemy lengths: remember full sightings, guess when the body runs out of view
#endif
#ifndef UNSEEN_LEN_GUESS
#define UNSEEN_LEN_GUESS 4 // assumed length of an enemy whose body leaves our view (never seen whole; 6 boxed the queen in)
#endif
#ifndef LEN_MEM_ROUNDS
#define LEN_MEM_ROUNDS 25 // a remembered length is trusted this long
#endif
#ifndef QUEEN_PAID_ESCAPE
#define QUEEN_PAID_ESCAPE 0 // every single step is inside some enemy's reach: sprint out, paying segments (off: with EVADE and
                            // STALKER_INTERCEPT it cost ~7 wins vs fleet11)
#endif
#ifndef QUEEN_EVADE
#define QUEEN_EVADE 0 // the queen drops pearls that lie in or next to an enemy's reach (off: see QUEEN_PAID_ESCAPE)
#endif
#ifndef STALKER_INTERCEPT
#define STALKER_INTERCEPT 0 // any short teammate strikes an enemy head that threatens our queen (off: see QUEEN_PAID_ESCAPE)
#endif
#ifndef BUNKER
#define BUNKER 1 // enemy queen dead: ours trims to length 2 and circles a sheltered 2x2 with no pearls
#endif
#ifndef EQ_DEATH_DETECT
#define EQ_DEATH_DETECT 1 // infer the enemy queen's death from death drops and fleet reports, and keep gossiping it
#endif
#ifndef EQ_STRICT
#define EQ_STRICT 1 // death inference only from a death drop on her own last-seen body (no area or report guesses: 2 false alarms in 176 games)
#endif
#ifndef BUNKER_SEARCH
#define BUNKER_SEARCH 25 // path distance searched for a bunker box
#endif
#ifndef QUEEN_ROOM
#define QUEEN_ROOM 0 // 1: teammates near the queen measure her free space (they rarely see her whole body; no gain)
#endif
#ifndef QUEEN_SPACE_PEN
#define QUEEN_SPACE_PEN 40000 // teammate head ending within 2 of the queen's head (PEN / 3.5 at distance 3)
#endif
#ifndef HUNTERS
#define HUNTERS 1 // part of the fleet hunts in coordinated packs (enemy queen first, then long dragons)
#endif
#ifndef HUNT_START
#define HUNT_START 60 // hunters start by this round (or as soon as expansion ends)
#endif
#ifndef HUNTER_SHARE
#define HUNTER_SHARE 3 // tenths of the non-leader fleet that hunt
#endif
#ifndef HUNTER_LEN
#define HUNTER_LEN 4 // hunters grow to this before going in (strike reach = free + L - 2 steps)
#endif
#ifndef HUNTER_SPLIT_LEN
#define HUNTER_SPLIT_LEN 8 // hunters still split from this length (both halves can strike); 0 = never
#endif
#ifndef PACK_SIZE
#define PACK_SIZE 3 // hunters sent at one long enemy dragon
#endif
#ifndef PREY_MIN_LEN
#define PREY_MIN_LEN 8 // enemy dragons this long are worth a small dragon in a head-on
#endif
#ifndef PACK_REGROUP
#define PACK_REGROUP 5 // a pack member this close to its prey waits for a mate (0 = off)
#endif
#ifndef ENDGAME_PACKS
#define ENDGAME_PACKS 1 // our queen dead: small dragons hunt in packs, long ones keep growing
#endif
#ifndef AGGRO_EXPANSION
#define AGGRO_EXPANSION 1 // while expanding: contest pearls nearer the enemy, push idle hunters toward its side
#endif
#ifndef PAID_REGICIDE
#define PAID_REGICIDE 1 // strike the visible enemy queen from as far as free + paid steps allow
#endif
#ifndef REGICIDE_MAX
#define REGICIDE_MAX 12
#endif
#ifndef GUARDS
#define GUARDS 1 // part of the fleet stays near our queen and intercepts enemies
#endif
#ifndef GUARD_SHARE
#define GUARD_SHARE 2 // tenths of the fleet that guard (hunters join once the enemy queen is dead)
#endif
#ifndef GUARD_RING
#define GUARD_RING 7 // guards come back when farther than this from the queen
#endif
#ifndef GUARD_MIN
#define GUARD_MIN 4 // guards never end a move this close to the queen's head (they screen, not crowd)
#endif
#ifndef GUARD_MIN_PEN
#define GUARD_MIN_PEN 60000 // per step inside GUARD_MIN
#endif
#ifndef GUARD_INTERCEPT
#define GUARD_INTERCEPT 6 // enemy heads this close to the queen are intercepted
#endif
#ifndef PORTAL_SCOUTS
#define PORTAL_SCOUTS 1 // the hunter group (and portal role) opens unknown portals from round 0
#endif
#ifndef SCOUT_REACH_PCT
#define SCOUT_REACH_PCT 50 // scout portals only while we can reach less than this % of the map without them
#endif
#ifndef SCOUT_PEARL_MARGIN
#define SCOUT_PEARL_MARGIN 4 // a scout keeps its pearl only if it is this much closer than the portal
#endif
#ifndef UNKNOWN_EDGE_COST
#define UNKNOWN_EDGE_COST 1 // >1: route cost of an edge nobody has seen (benchmarked at 2: about 8 wins worse)
#endif
#ifndef TARGET_COMMIT
#define TARGET_COMMIT 1 // keep the current pearl unless another is clearly closer
#endif
#ifndef COMMIT_MARGIN
#define COMMIT_MARGIN 4 // ... by this many steps and by 30%
#endif
#ifndef STALL_ROUNDS
#define STALL_ROUNDS 12 // no progress toward a pearl for this long: give it up (0 = off)
#endif
#ifndef STALL_SKIP
#define STALL_SKIP 30 // ... for this many rounds
#endif
#ifndef PREPOS_SLACK
#define PREPOS_SLACK 15 // head for a future pearl when its spawn is within travel time + this (not just 25 rounds)
#endif
#ifndef QUEEN_CLEAR
#define QUEEN_CLEAR 0 // >0: teammates keep this path distance from the queen's head (benchmarked at 4: fewer wall deaths, more head-ons)
#endif
#ifndef QUEEN_CLEAR_PEN
#define QUEEN_CLEAR_PEN 30000 // per step closer than QUEEN_CLEAR; doubled in corridors
#endif
#ifndef QUEEN_ROOM_PEN
#define QUEEN_ROOM_PEN 150000
#endif
#ifndef DIVE_ENABLE
#define DIVE_ENABLE 1 // non-queens value dead ends by the dive search
#endif
#ifndef QUEEN_SURV_RANK
#define QUEEN_SURV_RANK 1 // queen without a safe move prefers ways on over known dead ends
#endif
#ifndef FRONTIER_OPEN
#define FRONTIER_OPEN 0 // 1: non-leaders treat a way into unexplored water as an exit (benchmarked: no gain)
#endif
#ifndef SKIP_PEARL_ROUNDS
#define SKIP_PEARL_ROUNDS 0 // >0: ignore a pearl this long once it is only reachable at a loss (benchmarked: hurts)
#endif
#ifndef GUARD_MIN_UNITS
#define GUARD_MIN_UNITS 0 // >0: no guard duty while the fleet is smaller than this or still expanding (0 = always)
#endif
#ifndef TEAM_ADJ_PEN
#define TEAM_ADJ_PEN 4000 // non-leader ending next to a teammate's head (later movers see us anyway; dithers in corridors)
#endif
#ifndef QUEEN_COMMIT
#define QUEEN_COMMIT 0 // the queen keeps her pearl too (target commitment), instead of switching every turn
#endif
#ifndef HEIR
#define HEIR 1 // enemy queen dead: our longest other dragon becomes a leader (no growth splits, pearl priority)
#endif
#ifndef QUEEN_AVOID_PORTAL
#define QUEEN_AVOID_PORTAL 1 // the queen never crosses portals and keeps off cells with portal edges
#endif
#ifndef QUEEN_AVOID_UNKNOWN
#define QUEEN_AVOID_UNKNOWN 1 // the queen keeps to explored water and does not explore
#endif
#ifndef SNIPE
#define SNIPE 1 // short dragons sprint-strike any visible enemy head at least as long as themselves
#endif
#ifndef SNIPE_MAX_LEN
#define SNIPE_MAX_LEN 6 // only dragons this short strike (cheap trades)
#endif
#ifndef QUEEN_LOOP_SAFE
#define QUEEN_LOOP_SAFE 1 // the queen only moves (and splits) where she can still reach a free loop longer than she is
#endif
#ifndef QUEEN_LOOP_DEPTH
#define QUEEN_LOOP_DEPTH 15 // steps searched for that 2x2 (through known open water only)
#endif
#ifndef QUEEN_LOOP_PEN
#define QUEEN_LOOP_PEN 1000000 // a move after which no such 2x2 is reachable (pockets and long corridors trap short queens)
#endif
#ifndef QUEEN_EXIT_GUARD
#define QUEEN_EXIT_GUARD 1 // teammates never leave the queen fewer than 2 free exits (she moves first next round)
#endif
#ifndef QUEEN_EXIT_PEN
#define QUEEN_EXIT_PEN 2000000
#endif
#ifndef QUEEN_SEALED_NOSPLIT
#define QUEEN_SEALED_NOSPLIT 1 // queen starts in a kelp pocket closed within her first view (no portals): no optional splits
#endif
#ifndef SCREENS
#define SCREENS 1 // the first guard slot screens: posted 6-9 cells from the queen toward the enemy, on her row or column
#endif
#ifndef SCREEN_MIN
#define SCREEN_MIN 6
#endif
#ifndef SCREEN_MAX
#define SCREEN_MAX 9
#endif
#ifndef AIM_REPORTS
#define AIM_REPORTS 1 // enemy news goes out in the queen's direction when she is on our row or column
#endif
#ifndef REP_MAX_AGE
#define REP_MAX_AGE 3 // teammates' enemy reports the queen's threat map still uses (rounds)
#endif
#ifndef QUEEN_POS_RELAY
#define QUEEN_POS_RELAY 1 // relay the queen's fresh status ahead of gossip (guards and screens need her position)
#endif
#ifndef TIE_BUNKER
#define TIE_BUNKER 1 // late, both queens short and theirs no longer than ours: bunker at our length (no trim)
#endif
#ifndef TIE_BUNKER_ROUND
#define TIE_BUNKER_ROUND 350
#endif
#ifndef TIE_FORCE
#define TIE_FORCE 0 // test only: skip the enemy queen length check
#endif
#ifndef TIE_SEEN_ROUNDS
#define TIE_SEEN_ROUNDS 150 // how old the enemy queen's last exact length may be
#endif
#ifndef FAST_OPEN
#define FAST_OPEN 1 // 2.1: hunters split at EARLY_SPLIT_MIN_LEN too while the fleet is still expanding
#endif
#ifndef LANE_SPLIT
#define LANE_SPLIT 1 // 2.2: a dragon whose tail sits among spawn tiles splits there, the child inherits the lane
#endif
#ifndef LANE_TILES
#define LANE_TILES 3 // spawn tiles within 3 of the tail that make a lane
#endif
#ifndef LANE_DENSITY
#define LANE_DENSITY 8 // lane splits allowed up to one dragon per this many tiles
#endif
#ifndef CAMP_CONF
#define CAMP_CONF 0.85 // 2.3: confidence of an exactly known upcoming spawn (was 0.6)
#endif
#ifndef IDLE_CAMP
#define IDLE_CAMP 1 // 2.4: nothing to do and nothing unseen: camp the nearest free spawn tile
#endif
#ifndef RUNNERS
#define RUNNERS 1 // 2.5: explorer-role dragons on big maps stay length >= 5 (2 free steps a turn)
#endif
#ifndef RUNNER_MIN_CELLS
#define RUNNER_MIN_CELLS 1200
#endif
#ifndef RUNNER_KEEP
#define RUNNER_KEEP 5
#endif
#ifndef RUNNER_SPLIT_LEN
#define RUNNER_SPLIT_LEN 8
#endif
#ifndef PORTAL_ALWAYS
#define PORTAL_ALWAYS 1 // 2.6: scouts probe unknown portals whatever share of the map we can reach
#endif
#ifndef CONSOLIDATE
#define CONSOLIDATE 1 // big open maps: from CONSOL_ROUND no optional splits, spare dragons feed the queen (length wins there)
#endif
#ifndef CONSOL_ROUND
#define CONSOL_ROUND 350
#endif
#ifndef OPEN_MIN_CELLS
#define OPEN_MIN_CELLS 1000 // smaller maps are congested: numbers matter more than length
#endif
#ifndef OPEN_KELP_MAX
#define OPEN_KELP_MAX 0.20 // share of known edges that are kelp above which a map counts as congested
#endif
#ifndef CONSOL_MIN_UNITS
#define CONSOL_MIN_UNITS 10 // never feed the fleet below this (elimination)
#endif
#ifndef LATE_LONGEST_ONLY
#define LATE_LONGEST_ONLY 30 // last rounds: without our queen, feed only the longest leader (total length is the last tiebreak)
#endif
#ifndef OWN_HALF
#define OWN_HALF 1 // 17: pearls on our half count more; defenders (medium length) camp our half near the middle
#endif
#ifndef OWN_HALF_BONUS
#define OWN_HALF_BONUS 1.25
#endif
#ifndef DEFENDER_SLOT
#define DEFENDER_SLOT 5 // id-hash slot (0-9) of the defenders
#endif
#ifndef RECYCLE
#define RECYCLE 1 // 19: trapped with a teammate close by: self-destruct now so it eats the drop
#endif
#ifndef RECYCLE_MATE_DIST
#define RECYCLE_MATE_DIST 4
#endif
#ifndef PORTAL_ROW
#define PORTAL_ROW 1 // 20: never step through a portal onto/next to a teammate's head (lower id has right of way)
#endif
#ifndef PORTAL_ROW_PEN
#define PORTAL_ROW_PEN 2000000
#endif
#ifndef FEEDER_TRAIL
#define FEEDER_TRAIL 1 // 31: clusters of enemy death drops (their feeders) point at their queen
#endif
#ifndef GIANT
#define GIANT 1 // 25: open maps from CONSOL_ROUND: the longest non-queen leader is fed too (insurance)
#endif
#ifndef GIANT_SHARE
#define GIANT_SHARE 3 // one feeder in this many feeds the giant while the queen lives
#endif
#ifndef TIE_TRACK
#define TIE_TRACK 1 // 27: running guess of the round-500 tiebreaks steers feeding
#endif
#ifndef TIE_MARGIN
#define TIE_MARGIN 5 // lead that counts as safe on queen / longest length
#endif
#ifndef FEED_BEHIND_OPEN
#define FEED_BEHIND_OPEN 300 // behind on queen length: feeding starts here on open maps...
#endif
#ifndef FEED_BEHIND_CONGESTED
#define FEED_BEHIND_CONGESTED 400 // ...and here on congested ones
#endif
#ifndef QUEEN_LONG_LEN
#define QUEEN_LONG_LEN 12 // queens this long (feeding makes them) stay out of corridors
#endif
#ifndef QUEEN_CORRIDOR_PEN
#define QUEEN_CORRIDOR_PEN 300000
#endif
#ifndef FEED_CROWD
#define FEED_CROWD 3 // teammates already within 5 of the fed dragon: the rest wait
#endif
#ifndef PEARL_BEHIND_GAIN
#define PEARL_BEHIND_GAIN 4 // tail must be this much closer to use a pearl split
#endif
#ifndef PEARL_BEHIND_MAX
#define PEARL_BEHIND_MAX 10 // ...and the pearl at most this far from the tail
#endif

namespace {

// ---------------------------------------------------------------------------
// Geometry
// ---------------------------------------------------------------------------
constexpr int INF = 1 << 29;
constexpr int DX[4] = {0, 1, 0, -1};
constexpr int DY[4] = {-1, 0, 1, 0};
constexpr char DCH[4] = {'N', 'E', 'S', 'W'};

int W = 0, H = 0, N = 0;
int me = 0;
Team::Value myTeam = Team::A;
int R = 0;       // current round
int L = 3;       // my length
int units = 1;   // living dragons on my team
int unitLimit = 64;

int dir_index(Direction d)
{
    switch (d.value)
    {
    case Direction::NORTH: return 0;
    case Direction::EAST: return 1;
    case Direction::SOUTH: return 2;
    default: return 3;
    }
}
Direction dir_of(int i) { return Direction(DCH[i]); }

int cell_of(int x, int y) { return y * W + x; }
int cell_of(Position p) { return cell_of(p.x, p.y); }

int nb(int c, int d)
{
    int x = c % W + DX[d], y = c / W + DY[d];
    if (x < 0) x += W;
    else if (x >= W) x -= W;
    if (y < 0) y += H;
    else if (y >= H) y -= H;
    return y * W + x;
}

int wrap_dist(int a, int b, int n)
{
    int const d = std::abs(a - b);
    return std::min(d, n - d);
}
int manhattan(int a, int b) { return wrap_dist(a % W, b % W, W) + wrap_dist(a / W, b / W, H); }
int cheb(int a, int b) { return std::max(wrap_dist(a % W, b % W, W), wrap_dist(a / W, b / W, H)); }

std::mt19937 rng;

// ---------------------------------------------------------------------------
// World model: edges and portals
// ---------------------------------------------------------------------------
// Every edge is stored once. code = cell*2 + o, where o = 0 is the horizontal
// edge on the NORTH side of the cell and o = 1 the vertical edge on its WEST
// side. The south/east edges of a cell are the north/west edges of its
// southern/eastern neighbour (the map wraps).
enum : std::uint8_t { E_UNK = 0, E_OPEN = 1, E_KELP = 2, E_PORTAL = 3 };

std::vector<std::uint8_t> edgeType; // best knowledge (observed, told or mirrored)
std::vector<std::uint8_t> obsEdge;  // observed by us or a teammate (symmetry test)
std::vector<int> edgePid;           // portal id, -1 unknown
std::vector<int> edgePartner;       // partner edge code, -1 unknown
std::unordered_map<int, std::vector<int>> portalById;
std::vector<int> kelpList;                      // known kelp codes (gossip)
std::vector<std::pair<int, int>> portalPairs;   // known pairs (gossip)

int edge_code(int c, int d)
{
    switch (d)
    {
    case 0: return c * 2;
    case 1: return nb(c, 1) * 2 + 1;
    case 2: return nb(c, 2) * 2;
    default: return c * 2 + 1;
    }
}

// Where a head standing on c ends up after stepping in direction d.
//   >= 0 : the destination cell
//     -1 : kelp (death)
//     -2 : edge never seen
//     -3 : portal whose partner we have not located
// A portal keeps the heading: the head leaves the partner edge on its d side
// (verified in the engine with a test map).
int cross(int c, int d)
{
    int const code = edge_code(c, d);
    switch (edgeType[code])
    {
    case E_OPEN: return nb(c, d);
    case E_KELP: return -1;
    case E_UNK: return -2;
    default: break;
    }
    int const p = edgePartner[code];
    if (p < 0)
        return -3;
    int const pc = p >> 1;
    if ((p & 1) == 0) // partner is the north edge of pc
        return d == 2 ? pc : nb(pc, 0);
    return d == 1 ? pc : nb(pc, 3); // partner is the west edge of pc
}

// ---------------------------------------------------------------------------
// Symmetry (section 10)
// ---------------------------------------------------------------------------
// 0: mirror x -> W-1-x   1: mirror y -> H-1-y   2: rotate 180 degrees.
// These formulas were checked against every bundled map file.
int symMask = 7;
int symKnown = -1;
int symConfirm[3] = {0, 0, 0};
bool symFailed = false;

int mirror_cell(int k, int c)
{
    int x = c % W, y = c / W;
    if (k != 1) x = W - 1 - x;
    if (k != 0) y = H - 1 - y;
    return cell_of(x, y);
}

int mirror_edge(int k, int code)
{
    int const m = mirror_cell(k, code >> 1);
    if ((code & 1) == 0)
        return (k != 0 ? nb(m, 2) : m) * 2; // north edge maps to the mirrored south edge when y flips
    return (k != 1 ? nb(m, 1) : m) * 2 + 1; // west edge maps to the mirrored east edge when x flips
}

// ---------------------------------------------------------------------------
// World model: tiles and pearls (sections 6, 18)
// ---------------------------------------------------------------------------
std::vector<int> seenRound;  // last round the tile was in view, -1 never
std::vector<int> obsNext;    // observed next spawn round, -1 unknown, -2 never spawns
std::vector<int> nextSpawn;  // best estimate incl. mirrored/predicted, same encoding
std::vector<char> nextEst;   // nextSpawn is an estimate from observed gaps
std::vector<int> pearlState; // 0 none, 1 present (seen), 2 predicted
std::vector<int> dropRound;  // round a death-drop pearl (non-spawn tile) was first seen
std::vector<int> pearlRound; // round the pearlState info refers to
struct DropEv
{
    int cell, round;
    bool nearOurQueen; // likely one of our own feeders
};
std::vector<DropEv> dropEv; // death drops seen or heard of (non-spawn tiles), newest last
std::vector<int> gapLo, gapHi; // observed respawn gaps (0 = unknown)

// ---------------------------------------------------------------------------
// This turn's view of dragons
// ---------------------------------------------------------------------------
std::vector<char> vis;       // in view this turn
std::vector<int> occId;      // dragon id on the tile (in view), -1 none
std::vector<char> occMine;   // that dragon is on my team
std::vector<char> occHead;
std::vector<int> occDir;
std::vector<int> otherRel; // 0 free, else the earliest step at which that segment is gone
std::vector<char> contested; // free now, but another head could step here before our next move

struct HeadInfo
{
    int cell, id, len, dir;
    bool mine;
    int estLen = 0;       // enemies: best length estimate for strike reach (len counts only what is in view)
    bool partial = false; // body runs out of view
};
std::vector<HeadInfo> heads; // other dragons' heads in view
std::vector<int> enemyTails; // visible enemy tails that could split: a child's head appears there this round

std::vector<int> body; // my body, head first (may be shorter than L if unseen)
std::vector<int> prevBody;
std::vector<int> lastDirs; // steps of last turn's move (empty after a split)
std::unordered_map<int, int> prevTeamHeads; // teammate id -> head cell last turn

// ---------------------------------------------------------------------------
// Fleet knowledge (sonar)
// ---------------------------------------------------------------------------
struct Status
{
    int len, cell, round;
    bool leader;
};
std::unordered_map<int, Status> fleet;

struct EnemyRep
{
    int cell, round, id, len;
    int estLen = 0; // queen threat only: length guess when the body was not seen whole
};
std::vector<EnemyRep> enemyReps;
struct LenMem
{
    int len, round;
    bool exact;
};
std::unordered_map<int, LenMem> enemyLenMem; // enemy id -> last observed length (exact = whole body seen)

// Length of an enemy for its strike reach: exact when the whole body is in
// view, otherwise the last exact sighting, and at least a guess when we never
// saw it whole (a long hunter shows only its head at the edge of our window).
int est_enemy_len(int id, int seen, bool partial)
{
    if (!ENEMY_LEN_MEMORY || !partial)
        return seen;
    auto const it = enemyLenMem.find(id);
    if (it != enemyLenMem.end() && R - it->second.round <= LEN_MEM_ROUNDS)
        return std::max({seen, it->second.len, it->second.exact ? 0 : UNSEEN_LEN_GUESS});
    return std::max(seen, UNSEEN_LEN_GUESS);
}
void remember_enemy_len(int id, int len, bool exact)
{
    auto it = enemyLenMem.find(id);
    if (exact || it == enemyLenMem.end() || R - it->second.round > LEN_MEM_ROUNDS)
        enemyLenMem[id] = {len, R, exact};
    else if (!it->second.exact || len > it->second.len)
        it->second = {std::max(it->second.len, len), R, it->second.exact && len <= it->second.len};
}

struct Danger
{
    int cell, round, cause; // cause 1 = enemy involved, 2 = hazard / trap
};
std::vector<Danger> dangers;

struct Claim
{
    int id, eta, round;
};
std::unordered_map<int, Claim> claims; // pearl cell -> claim

// ---------------------------------------------------------------------------
// Strategy state
// ---------------------------------------------------------------------------
enum Role { ROLE_COLLECTOR, ROLE_EXPLORER, ROLE_PORTAL, ROLE_COMBAT };
enum Mode { MODE_NORMAL, MODE_FARM, MODE_PRESERVE, MODE_COMBAT };

Role role = ROLE_COLLECTOR;
Mode mode = MODE_NORMAL;
bool isLeader = false;
bool isDefender = false; // holds our half (medium length, camps near the middle)
bool openMap = false;     // big map with little kelp: long dragons do not trap themselves
bool consolidate = false; // big open map, late: length over numbers
bool isScreen = false; // guard posted out toward the enemy to see attackers early
bool isHeir = false; // enemy queen dead: the dragon that grows instead of our queen
bool sealedChecked = false, queenSealed = false;
int sealedCells = 0; // size of the queen's sealed starting pocket
int queenId = 0, enemyQueenId = 1; // ids 0 and 1 are the queens; which is ours is learned
bool amQueen = false;
bool ourQueenDead = false, enemyQueenDead = false;
int prevEnemyQueenCell = -1;
int prevEnemyQueenLen = 0;
std::vector<int> prevEnemyQueenBody, eqBodyNow; // her body cells we saw last turn / this turn
int ourQueenSpawn = -1; // where our queen started (the enemy queen started at its mirror image)
int lastPearl = -1;     // the pearl this dragon went for last turn
int stallTarget = -1, stallBest = INF, stallRound = 0; // progress toward the current pearl
bool isHunter = false;
bool isGuard = false;
bool hunterSlot = false; // in the hunter group (scouts portals before the hunt starts)
bool queenSeen = false; // queen identity confirmed by vision (team is shown there)
bool transitioned = false;
bool expansionPhase = true; // numbers first, until the fleet first reaches its expansion target
bool queenSplits = true;    // the queen splits rather than grows (see QUEEN_GROW_ROUND)
int transitionRound = 300;
int localThreat = 0;
int distinctEnemies = 0;
int echoEnemy = 0;
int exploreGoal = -1, exploreSetRound = -1000;
int claimTarget = -1, claimEta = 0;
std::string note;

// ---------------------------------------------------------------------------
// Sonar messages
// ---------------------------------------------------------------------------
// [63..56] magic  [55..52] type  [51..48] checksum  [47..0] payload
constexpr std::uint64_t MAGIC = 0xB7;
enum MsgType
{
    T_STATUS = 1,
    T_PEARL = 2,
    T_PORTAL = 3,
    T_KELP = 4,
    T_ENEMY = 5,
    T_DANGER = 6,
    T_SYM = 7,
    T_CLAIM = 8,
    T_PORTAL_EDGE = 9,
    T_QUEEN_DEAD = 10,
    T_QSPAWN = 11,
};

struct BitW
{
    std::uint64_t v = 0;
    int pos = 0;
    void put(std::uint64_t x, int bits)
    {
        v |= (x & ((1ULL << bits) - 1)) << pos;
        pos += bits;
    }
};
struct BitR
{
    std::uint64_t v;
    int pos = 0;
    explicit BitR(std::uint64_t v) : v(v) {}
    int get(int bits)
    {
        int const x = static_cast<int>((v >> pos) & ((1ULL << bits) - 1));
        pos += bits;
        return x;
    }
};

std::uint64_t checksum(int type, std::uint64_t payload)
{
    // Salted by team, so the other side's copy of this bot fails validation.
    std::uint64_t cs = static_cast<std::uint64_t>(type) ^ (myTeam == Team::A ? 0x5 : 0xA);
    for (int i = 0; i < 12; i++)
        cs ^= (payload >> (4 * i)) & 15;
    return cs;
}

std::uint64_t pack(int type, std::uint64_t payload)
{
    payload &= (1ULL << 48) - 1;
    return (MAGIC << 56) | (static_cast<std::uint64_t>(type) << 52) | (checksum(type, payload) << 48) | payload;
}

bool unpack(std::uint64_t m, int& type, std::uint64_t& payload)
{
    if ((m >> 56) != MAGIC)
        return false;
    type = static_cast<int>((m >> 52) & 15);
    payload = m & ((1ULL << 48) - 1);
    return ((m >> 48) & 15) == checksum(type, payload);
}

struct Fact
{
    std::uint64_t msg;
    int prio, sends;
};
std::vector<Fact> facts;

void queue_fact(std::uint64_t msg, int prio, int sends)
{
    for (auto& f : facts)
        if (f.msg == msg)
        {
            f.prio = std::max(f.prio, prio);
            f.sends = std::max(f.sends, sends);
            return;
        }
    facts.push_back({msg, prio, sends});
    if (facts.size() > 64)
    {
        auto it = std::min_element(facts.begin(), facts.end(), [](Fact const& a, Fact const& b) { return a.prio < b.prio; });
        facts.erase(it);
    }
}

struct PearlEntry
{
    int kind, cell, round, prio; // kind 0 next spawn at round, 1 present at round, 2 gone at round
};
std::vector<PearlEntry> pearlQ;

void queue_pearl(int kind, int cell, int round, int prio)
{
    for (auto& e : pearlQ)
        if (e.cell == cell && e.kind == kind)
        {
            e.round = round;
            e.prio = std::max(e.prio, prio);
            return;
        }
    pearlQ.push_back({kind, cell, round, prio});
    if (pearlQ.size() > 40)
    {
        auto it = std::min_element(pearlQ.begin(), pearlQ.end(), [](PearlEntry const& a, PearlEntry const& b) { return a.prio < b.prio; });
        pearlQ.erase(it);
    }
}

std::uint64_t msg_status()
{
    BitW b;
    b.put(me, 14);
    b.put(std::min(L, 1023), 10);
    b.put(body.empty() ? 0 : body[0], 12);
    b.put(isLeader ? 1 : 0, 1);
    b.put(R, 9);
    return pack(T_STATUS, b.v);
}
std::uint64_t msg_portal(int a, int c)
{
    BitW b;
    b.put(a, 13);
    b.put(c, 13);
    return pack(T_PORTAL, b.v);
}
std::uint64_t msg_portal_edge(int code, int pid)
{
    BitW b;
    b.put(code, 13);
    b.put(pid, 20);
    return pack(T_PORTAL_EDGE, b.v);
}
std::uint64_t msg_enemy(int cell, int id, int len, bool partial = false)
{
    BitW b;
    b.put(cell, 12);
    b.put(R, 9);
    b.put(id, 14);
    b.put(std::min(len, 255), 8);
    b.put(partial ? 1 : 0, 1); // len is only what the sender saw
    return pack(T_ENEMY, b.v);
}
std::uint64_t msg_danger(int cell, int cause)
{
    BitW b;
    b.put(cell, 12);
    b.put(R, 9);
    b.put(cause, 3);
    return pack(T_DANGER, b.v);
}
std::uint64_t msg_sym()
{
    BitW b;
    b.put(symKnown, 2);
    return pack(T_SYM, b.v);
}
std::uint64_t msg_queen_dead(bool enemy)
{
    BitW b;
    b.put(enemy ? 1 : 0, 1);
    b.put(enemy ? enemyQueenId : queenId, 2);
    return pack(T_QUEEN_DEAD, b.v);
}
std::uint64_t msg_qspawn(int cell)
{
    BitW b;
    b.put(cell, 12);
    return pack(T_QSPAWN, b.v);
}
std::uint64_t msg_claim(int cell, int eta)
{
    BitW b;
    b.put(me, 14);
    b.put(cell, 12);
    b.put(std::min(eta, 255), 8);
    b.put(R, 9);
    return pack(T_CLAIM, b.v);
}

// ---------------------------------------------------------------------------
// Learning
// ---------------------------------------------------------------------------
void check_edge_symmetry(int code)
{
    for (int k = 0; k < 3; k++)
    {
        if (!(symMask & (1 << k)))
            continue;
        int const mc = mirror_edge(k, code);
        if (obsEdge[mc] == E_UNK)
            continue;
        if (obsEdge[mc] != obsEdge[code])
            symMask &= ~(1 << k);
        else
            symConfirm[k]++;
    }
}

void set_partner(int a, int b)
{
    if (a == b || edgePartner[a] == b)
        return;
    edgePartner[a] = b;
    edgePartner[b] = a;
    if (edgeType[a] == E_UNK) edgeType[a] = E_PORTAL;
    if (edgeType[b] == E_UNK) edgeType[b] = E_PORTAL;
    portalPairs.push_back({a, b});
}

void mirror_pair(int a, int b)
{
    if (symKnown < 0)
        return;
    int const ma = mirror_edge(symKnown, a), mb = mirror_edge(symKnown, b);
    if (edgePartner[ma] < 0 && edgePartner[mb] < 0 && ma != mb)
        set_partner(ma, mb);
}

// Record an edge. direct = seen by a dragon (us or a teammate), which is what
// symmetry testing trusts. Returns true if it taught us something new.
bool learn_edge(int code, std::uint8_t type, int pid, bool direct)
{
    bool changed = false;
    if (edgeType[code] != type)
    {
        edgeType[code] = type;
        changed = true;
        if (type == E_KELP)
            kelpList.push_back(code);
    }
    if (direct && obsEdge[code] != type)
    {
        obsEdge[code] = type;
        check_edge_symmetry(code);
    }
    if (type == E_PORTAL && pid >= 0 && edgePid[code] != pid)
    {
        edgePid[code] = pid;
        changed = true;
        auto& v = portalById[pid];
        if (std::find(v.begin(), v.end(), code) == v.end())
            v.push_back(code);
        if (v.size() == 2 && edgePartner[v[0]] != v[1])
        {
            set_partner(v[0], v[1]);
            mirror_pair(v[0], v[1]);
            queue_fact(msg_portal(v[0], v[1]), 85, 4); // section 5: share portal structure
        }
        else if (v.size() == 1)
            queue_fact(msg_portal_edge(code, pid), 40, 2);
    }
    if (symKnown >= 0)
    {
        int const mc = mirror_edge(symKnown, code);
        if (edgeType[mc] == E_UNK)
        {
            edgeType[mc] = type;
            if (type == E_KELP)
                kelpList.push_back(mc);
        }
    }
    return changed;
}

void mirror_tile(int c)
{
    if (symKnown < 0)
        return;
    int const m = mirror_cell(symKnown, c);
    if (m == c || seenRound[m] == R)
        return;
    // Mirrored tiles share one countdown, so the timing carries over exactly.
    if (nextSpawn[c] != -1 && (nextSpawn[m] == -1 || seenRound[m] < seenRound[c]))
    {
        nextSpawn[m] = nextSpawn[c];
        nextEst[m] = nextEst[c];
    }
    if (gapLo[m] == 0 && gapLo[c] > 0)
    {
        gapLo[m] = gapLo[c];
        gapHi[m] = gapHi[c];
    }
}

void note_drop(int c, int round)
{
    if (!FEEDER_TRAIL)
        return;
    for (auto const& e : dropEv)
        if (e.cell == c && std::abs(e.round - round) <= 2)
            return;
    bool nearQ = false;
    auto const q = fleet.find(queenId);
    if (!ourQueenDead && q != fleet.end() && R - q->second.round <= 20 && manhattan(q->second.cell, c) <= 6)
        nearQ = true;
    if (!ourQueenDead && me == queenId && !body.empty() && manhattan(body[0], c) <= 6)
        nearQ = true;
    dropEv.push_back({c, round, nearQ});
    if (dropEv.size() > 64)
        dropEv.erase(dropEv.begin());
}

void observe_tile(int c, bool pearl, int k)
{
    int const ns = k < 0 ? -2 : R + std::max(k, 0);
    // A reset between two sightings reveals one draw of the tile's hidden gap.
    if (obsNext[c] >= 0 && obsNext[c] <= R && ns >= 0 && ns > obsNext[c])
    {
        int const g = ns - obsNext[c];
        gapLo[c] = gapLo[c] == 0 ? g : std::min(gapLo[c], g);
        gapHi[c] = std::max(gapHi[c], g);
    }
    bool const newTiming = obsNext[c] != ns;
    bool const wasPresent = pearlState[c] == 1;
    seenRound[c] = R;
    obsNext[c] = ns;
    nextSpawn[c] = ns;
    nextEst[c] = 0;

    // Symmetry test on shared countdowns.
    for (int kk = 0; kk < 3; kk++)
    {
        if (!(symMask & (1 << kk)))
            continue;
        int const m = mirror_cell(kk, c);
        if (m == c || seenRound[m] < 0 || obsNext[m] == -1)
            continue;
        bool const neverA = ns == -2, neverB = obsNext[m] == -2;
        if (neverA != neverB)
            symMask &= ~(1 << kk);
        else if (!neverA && ns > R && obsNext[m] > R)
        {
            if (ns == obsNext[m])
                symConfirm[kk]++;
            else
                symMask &= ~(1 << kk);
        }
    }

    if (pearl)
    {
        if (!wasPresent && k < 0)
        {
            dropRound[c] = R; // a pearl on a tile that never spawns: a death drop
            note_drop(c, R);
        }
        if (!wasPresent)
        {
            queue_pearl(1, c, R, k < 0 ? 75 : 60); // death drops first: teammates come and collect
            // A fresh pearl here means the mirrored tile fired at the same moment.
            if (symKnown >= 0)
            {
                int const m = mirror_cell(symKnown, c);
                if (m != c && seenRound[m] < R && pearlState[m] == 0)
                {
                    pearlState[m] = 2;
                    pearlRound[m] = R;
                }
            }
        }
        pearlState[c] = 1;
    }
    else
    {
        if (wasPresent)
            queue_pearl(2, c, R, 35);
        pearlState[c] = 0;
    }
    pearlRound[c] = R;
    if (newTiming && ns >= 0 && ns - R <= 25)
        queue_pearl(0, c, ns, 25);
    mirror_tile(c);
}

// Tiles out of view whose countdown ran out: a pearl probably spawned there.
void update_unobserved()
{
    for (int c = 0; c < N; c++)
    {
        int const ns = nextSpawn[c];
        if (ns < 0 || ns > R || seenRound[c] >= ns)
            continue;
        if (pearlState[c] == 0)
        {
            pearlState[c] = 2;
            pearlRound[c] = ns;
        }
        if (gapLo[c] > 0)
        {
            nextSpawn[c] = ns + (gapLo[c] + gapHi[c]) / 2;
            nextEst[c] = 1;
        }
        else
            nextSpawn[c] = -1;
    }
}

void set_symmetry(int k)
{
    if (symKnown >= 0 || k < 0 || k > 2)
        return;
    symKnown = k;
    queue_fact(msg_sym(), 90, 4);
    int const codes = N * 2;
    for (int code = 0; code < codes; code++)
    {
        if (obsEdge[code] == E_UNK)
            continue;
        int const mc = mirror_edge(k, code);
        if (edgeType[mc] == E_UNK)
        {
            edgeType[mc] = obsEdge[code];
            if (obsEdge[code] == E_KELP)
                kelpList.push_back(mc);
        }
    }
    auto const pairs = portalPairs;
    for (auto const& [a, b] : pairs)
        mirror_pair(a, b);
    for (int c = 0; c < N; c++)
        if (seenRound[c] >= 0)
            mirror_tile(c);
}

void resolve_symmetry()
{
    if (symKnown >= 0 || symFailed)
        return;
    if (symMask == 0)
    {
        symFailed = true; // inconsistent observations: stop predicting
        return;
    }
    int bits = 0, first = -1;
    bool allConfirmed = true;
    for (int k = 0; k < 3; k++)
        if (symMask & (1 << k))
        {
            bits++;
            if (first < 0) first = k;
            if (symConfirm[k] < 80) allConfirmed = false;
        }
    // Several survivors with lots of evidence: the map has several symmetries,
    // and any of them predicts correctly.
    if (bits == 1 || allConfirmed)
        set_symmetry(first);
}

// ---------------------------------------------------------------------------
// Reading the turn
// ---------------------------------------------------------------------------
void read_vision(Controller& ct)
{
    std::fill(vis.begin(), vis.end(), 0);
    std::fill(occId.begin(), occId.end(), -1);
    heads.clear();
    enemyTails.clear();
    eqBodyNow.clear();
    std::unordered_map<int, int> partCount;

    for (Tile const& tile : ct.get_tiles())
    {
        int const c = cell_of(tile.get_position());
        vis[c] = 1;
        observe_tile(c, tile.has_pearl(), tile.get_pearl_time());
        for (int d = 0; d < 4; d++)
        {
            Edge const& e = tile.get_edge(dir_of(d));
            std::uint8_t const t = e.get_edge_type() == EdgeType::KELP ? E_KELP
                                 : e.get_edge_type() == EdgeType::PORTAL ? E_PORTAL
                                                                        : E_OPEN;
            learn_edge(edge_code(c, d), t, e.get_portal_id(), true);
        }
        if (DragonPart const* p = tile.get_dragon())
        {
            occId[c] = p->get_id();
            occMine[c] = p->get_team() == myTeam;
            occHead[c] = p->is_head();
            occDir[c] = dir_index(p->get_dir());
            partCount[p->get_id()]++;
            if (p->get_id() <= 1 && me > 1)
            {
                bool const ours = p->get_team() == myTeam;
                queenSeen = true;
                queenId = ours ? p->get_id() : 1 - p->get_id();
                enemyQueenId = 1 - queenId;
            }
            // A pearl can never sit under a dragon.
            pearlState[c] = 0;
        }
    }
    for (Tile const& tile : ct.get_tiles())
    {
        DragonPart const* p = tile.get_dragon();
        if (!p || !p->is_head() || p->get_id() == me)
            continue;
        heads.push_back({cell_of(tile.get_position()), p->get_id(), partCount[p->get_id()],
                         dir_index(p->get_dir()), p->get_team() == myTeam});
    }

    // Other dragons: solid by default, time-released when the whole body is visible.
    int const myHead = cell_of(ct.get_position());
    for (int c = 0; c < N; c++)
    {
        otherRel[c] = (vis[c] && occId[c] >= 0 && occId[c] != me) ? INF : 0;
        contested[c] = 0;
    }
    for (auto const& h : heads)
        for (int d = 0; d < 4; d++)
        {
            int const n = nb(h.cell, d);
            if (!(vis[n] && occId[n] >= 0))
                contested[n] = 1;
        }
    // The queen also assumes enemies use their free sprint steps.
    if (me == queenId && !QUEEN_THREAT_MAP)
        for (auto const& h : heads)
        {
            if (h.mine)
                continue;
            int const reach = std::max(1, (h.len + 3) / 4);
            if (reach <= 1)
                continue;
            for (int c = 0; c < N; c++)
                if (vis[c] && !(occId[c] >= 0) && manhattan(c, h.cell) <= reach)
                    contested[c] = 1;
        }
    for (auto& h : heads)
    {
        std::vector<int> chain{h.cell};
        for (bool grew = true; grew;)
        {
            grew = false;
            int const cur = chain.back();
            for (int d = 0; d < 4; d++)
            {
                int const n = nb(cur, d);
                if (vis[n] && occId[n] == h.id && !occHead[n] && nb(n, occDir[n]) == cur &&
                    std::find(chain.begin(), chain.end(), n) == chain.end())
                {
                    chain.push_back(n);
                    grew = true;
                    break;
                }
            }
        }
        int const m = static_cast<int>(chain.size());
        bool const partial = m != partCount[h.id] || cheb(chain.back(), myHead) > 2;
        if (!h.mine && h.id == enemyQueenId)
            eqBodyNow = chain;
        if (!h.mine)
        {
            h.partial = partial;
            h.estLen = est_enemy_len(h.id, std::max(m, partCount[h.id]), partial);
            remember_enemy_len(h.id, partial ? std::max(m, partCount[h.id]) : m, !partial);
        }
        if (partial)
            continue; // tail may continue out of view
        if (!h.mine && m >= 4)
            enemyTails.push_back(chain.back());
        for (int i = 0; i < m; i++)
            otherRel[chain[i]] = (m - 1 - i) + 3;
    }
}

// Own body: follow the facing chain from the head inside the window, then
// extend with last turn's body for the part that is out of view.
void update_body(Controller& ct)
{
    int const head = cell_of(ct.get_position());
    std::vector<int> chain{head};
    std::vector<char> inChain(N, 0);
    inChain[head] = 1;
    while (static_cast<int>(chain.size()) < L)
    {
        int const cur = chain.back();
        int found = -1;
        for (int d = 0; d < 4 && found < 0; d++)
        {
            int const n = nb(cur, d);
            if (vis[n] && occId[n] == me && !inChain[n] && !occHead[n] && nb(n, occDir[n]) == cur)
                found = n;
        }
        if (found < 0)
            break;
        chain.push_back(found);
        inChain[found] = 1;
    }
    // Replay last turn's steps from last turn's body: exact even when the
    // body is broken across a portal or the move was a sprint.
    if (!prevBody.empty())
    {
        std::vector<int> path;
        int pos = prevBody[0];
        bool ok = true;
        for (std::size_t i = 0; i < lastDirs.size(); i++)
        {
            pos = cross(pos, lastDirs[i]);
            if (pos < 0)
            {
                if (pos == -3 && i + 1 == lastDirs.size())
                    pos = head; // first trip through this portal: we now stand at its far side
                else
                {
                    ok = false;
                    break;
                }
            }
            path.push_back(pos);
        }
        if (ok && pos == head)
        {
            std::vector<int> pred(path.rbegin(), path.rend());
            pred.insert(pred.end(), prevBody.begin(), prevBody.end());
            if (static_cast<int>(pred.size()) > L)
                pred.resize(L);
            bool consistent = true;
            for (std::size_t i = 0; i < chain.size() && i < pred.size(); i++)
                consistent &= chain[i] == pred[i];
            if (consistent && pred.size() >= chain.size())
            {
                body = pred;
                return;
            }
        }
    }
    if (static_cast<int>(chain.size()) < L && !prevBody.empty())
    {
        auto const it = std::find(prevBody.begin(), prevBody.end(), chain.back());
        if (it != prevBody.end())
            for (auto j = it + 1; j != prevBody.end() && static_cast<int>(chain.size()) < L; ++j)
                if (!inChain[*j])
                {
                    chain.push_back(*j);
                    inChain[*j] = 1;
                }
    }
    body = chain;
}

void prune_knowledge()
{
    std::erase_if(enemyReps, [](EnemyRep const& e) { return R - e.round > 60; });
    std::erase_if(dangers, [](Danger const& d) { return R - d.round > 60; });
    std::erase_if(fleet, [](auto const& kv) { return R - kv.second.round > 60; });
    std::erase_if(claims, [](auto const& kv) { return R - kv.second.round > 6; });
    if (enemyReps.size() > 200)
        enemyReps.erase(enemyReps.begin(), enemyReps.begin() + (enemyReps.size() - 200));
    if (dangers.size() > 100)
        dangers.erase(dangers.begin(), dangers.begin() + (dangers.size() - 100));
}

void add_enemy(int cell, int round, int id, int len, int estLen = 0)
{
    for (auto& e : enemyReps)
        if (e.id == id && e.round <= round)
        {
            e = {cell, round, id, len, estLen};
            return;
        }
    enemyReps.push_back({cell, round, id, len, estLen});
}

// Returns true if the message taught us something (so it is worth relaying).
bool apply_message(std::uint64_t m)
{
    int type;
    std::uint64_t payload;
    if (!unpack(m, type, payload))
        return false;
    BitR b(payload);
    switch (type)
    {
    case T_STATUS: {
        int const id = b.get(14), len = b.get(10), cell = b.get(12), leader = b.get(1), round = b.get(9);
        if (id == me || cell >= N || round > R)
            return false;
        if (id <= 1 && me > 1 && !queenSeen) // only teammates speak our protocol, so this is our queen
        {
            queenId = id;
            enemyQueenId = 1 - id;
        }
        auto it = fleet.find(id);
        if (it != fleet.end() && it->second.round >= round)
            return false;
        fleet[id] = {len, cell, round, leader == 1};
        if (id == queenId)
            return true; // relay the queen's position across the fleet
        return leader == 1;
    }
    case T_PEARL: {
        bool changed = false;
        int const count = 1 + b.get(1);
        for (int i = 0; i < count; i++)
        {
            int const kind = b.get(2), cell = b.get(12), round = b.get(9);
            if (cell >= N)
                continue;
            if (kind == 0 && round >= R && (obsNext[cell] < R || obsNext[cell] == -1) && obsNext[cell] != -2)
            {
                obsNext[cell] = round;
                nextSpawn[cell] = round;
                nextEst[cell] = 0;
                mirror_tile(cell);
                changed = true;
            }
            else if (kind == 1 && pearlRound[cell] < round)
            {
                if (nextSpawn[cell] == -2 && pearlState[cell] != 1)
                    note_drop(cell, round); // a teammate saw a death drop
                pearlState[cell] = 1;
                pearlRound[cell] = round;
                changed = true;
            }
            else if (kind == 2 && pearlRound[cell] <= round && pearlState[cell] != 0)
            {
                pearlState[cell] = 0;
                pearlRound[cell] = round;
                changed = true;
            }
        }
        return changed;
    }
    case T_PORTAL: {
        int const a = b.get(13), c = b.get(13);
        if (a >= 2 * N || c >= 2 * N || edgePartner[a] == c)
            return false;
        set_partner(a, c);
        mirror_pair(a, c);
        return true;
    }
    case T_PORTAL_EDGE: {
        int const code = b.get(13), pid = b.get(20);
        if (code >= 2 * N || edgePid[code] == pid)
            return false;
        return learn_edge(code, E_PORTAL, pid, true);
    }
    case T_KELP: {
        bool changed = false;
        int const count = b.get(2);
        for (int i = 0; i < count; i++)
        {
            int const code = b.get(13);
            if (code < 2 * N && edgeType[code] != E_KELP)
                changed |= learn_edge(code, E_KELP, -1, true);
        }
        return changed;
    }
    case T_ENEMY: {
        int const cell = b.get(12), round = b.get(9), id = b.get(14), len = b.get(8);
        bool const partial = b.get(1) == 1;
        if (cell >= N || round > R)
            return false;
        if (R - round <= 2)
            remember_enemy_len(id, len, !partial);
        add_enemy(cell, round, id, len, est_enemy_len(id, len, partial));
        return R - round <= 2;
    }
    case T_DANGER: {
        int const cell = b.get(12), round = b.get(9), cause = b.get(3);
        if (cell >= N || round > R)
            return false;
        for (auto const& d : dangers)
            if (d.cell == cell && d.round == round)
                return false;
        dangers.push_back({cell, round, cause});
        return true;
    }
    case T_SYM: {
        int const k = b.get(2);
        if (symKnown >= 0 || k > 2 || !(symMask & (1 << k)))
            return false;
        set_symmetry(k);
        return true;
    }
    case T_QSPAWN: {
        int const cell = static_cast<int>(b.get(12));
        if (ourQueenSpawn < 0 && cell < N)
        {
            ourQueenSpawn = cell;
            return true;
        }
        return false;
    }
    case T_QUEEN_DEAD: {
        bool const enemy = b.get(1) == 1;
        if (enemy && !enemyQueenDead)
        {
            enemyQueenDead = true;
            return true;
        }
        if (!enemy && !ourQueenDead && !amQueen)
        {
            ourQueenDead = true;
            return true;
        }
        return false;
    }
    case T_CLAIM: {
        int const id = b.get(14), cell = b.get(12), eta = b.get(8), round = b.get(9);
        if (id == me || cell >= N || round > R)
            return false;
        auto it = claims.find(cell);
        if (it != claims.end() && it->second.round > round)
            return false;
        claims[cell] = {id, eta, round};
        return false;
    }
    default:
        return false;
    }
}

void read_sonar(Controller& ct)
{
    for (std::uint64_t const m : ct.get_sonar_messages())
        if (apply_message(m))
        {
            int type;
            std::uint64_t payload;
            int prio = 15;
            bool const typed = unpack(m, type, payload);
            if (QUEEN_POS_RELAY && typed && type == T_STATUS && me != queenId)
            {
                // The queen's position: guards and screens need it, so it goes
                // out ahead of pearl gossip while fresh.
                int const id = static_cast<int>(payload & 0x3FFF);
                int const round = static_cast<int>((payload >> 37) & 0x1FF);
                if (id == queenId && R - round <= 4)
                    prio = 45;
                else if (GIANT && ((payload >> 36) & 1) && R - round <= 4)
                    prio = 35; // leaders (the giant among them) are fed too
            }
            if (AIM_REPORTS && me != queenId && typed && type == T_ENEMY)
            {
                // An enemy near our queen: pass it on first (and toward her).
                auto const q = fleet.find(queenId);
                int const cell = static_cast<int>(payload & 0xFFF);
                if (q != fleet.end() && R - q->second.round <= 3 && cell < N && manhattan(cell, q->second.cell) <= 14)
                    prio = 85;
            }
            queue_fact(m, prio, prio > 15 ? 1 : 2); // gossip: pass new facts along the chain
        }
    SonarEchoes const e = ct.get_sonar_echoes();
    echoEnemy = e.enemy + e.enemy_head;
}

// Section 17: a teammate that vanished from the middle of our window died.
void detect_teammate_deaths()
{
    int const head = body[0];
    std::unordered_set<int> visibleIds;
    for (int c = 0; c < N; c++)
        if (vis[c] && occId[c] >= 0)
            visibleIds.insert(occId[c]);
    for (auto const& [id, cell] : prevTeamHeads)
    {
        if (visibleIds.count(id) || cheb(cell, head) > 2)
            continue;
        int cause = 2;
        for (auto const& h : heads)
            if (!h.mine && manhattan(h.cell, cell) <= 2)
                cause = 1;
        dangers.push_back({cell, R, cause});
        queue_fact(msg_danger(cell, cause), 75, 3);
        fleet.erase(id);
        if (id == queenId && !ourQueenDead)
        {
            ourQueenDead = true;
            queue_fact(msg_queen_dead(false), 95, 4);
        }
    }
    // The enemy queen vanished from the middle of our window: it died. Or she
    // is out of view and a death-drop pearl (on a tile that never spawns) lies
    // on her last body or within one turn's move of her head: a head-on kills
    // both, and the striker's own sonar dies with it, so watchers must tell.
    if (prevEnemyQueenCell >= 0 && !enemyQueenDead && !visibleIds.count(enemyQueenId))
    {
        int const fq = EQ_DEATH_DETECT ? std::max(1, (prevEnemyQueenLen + 3) / 4) : 1;
        bool dead = cheb(prevEnemyQueenCell, head) <= 3 - fq;
        for (int c = 0; c < N && !dead && EQ_DEATH_DETECT; c++)
        {
            if (!vis[c] || dropRound[c] != R)
                continue;
            if ((!EQ_STRICT && manhattan(c, prevEnemyQueenCell) <= fq) ||
                std::find(prevEnemyQueenBody.begin(), prevEnemyQueenBody.end(), c) != prevEnemyQueenBody.end())
                dead = true;
        }
        if (dead)
        {
            enemyQueenDead = true;
            queue_fact(msg_queen_dead(true), 95, 4);
        }
    }
    // The same from a fleet report of her (at most three rounds old: a watcher
    // that moves before the striker sees the drop only next round): a fresh
    // death drop near where she was, and she is not in our window.
    if (EQ_DEATH_DETECT && !EQ_STRICT && !enemyQueenDead && !visibleIds.count(enemyQueenId))
        for (auto const& e : enemyReps)
        {
            int const age = R - e.round;
            if (e.id != enemyQueenId || age < 1 || age > 3 || cheb(e.cell, head) > 3 + age)
                continue;
            int const rad = std::min(3, std::max(1, (e.len + 3) / 4) * age);
            if (cheb(e.cell, head) + rad <= 3)
            {
                enemyQueenDead = true; // every cell she could have reached is in view, and she is not
                queue_fact(msg_queen_dead(true), 95, 4);
                break;
            }
            for (int c = 0; c < N; c++)
                if (vis[c] && dropRound[c] == R && manhattan(c, e.cell) <= rad)
                {
                    enemyQueenDead = true;
                    queue_fact(msg_queen_dead(true), 95, 4);
                    break;
                }
        }
    prevEnemyQueenCell = -1;
    prevEnemyQueenBody = eqBodyNow;
    for (auto const& h : heads)
        if (!h.mine && h.id == enemyQueenId)
        {
            prevEnemyQueenCell = h.cell;
            prevEnemyQueenLen = std::max(h.len, h.estLen);
        }
    prevTeamHeads.clear();
    for (auto const& h : heads)
        if (h.mine)
            prevTeamHeads[h.id] = h.cell;
}

void record_enemies()
{
    int shared = 0;
    for (auto const& h : heads)
    {
        if (h.mine)
            continue;
        add_enemy(h.cell, R, h.id, h.len, h.estLen);
        if (h.id == enemyQueenId)
            queue_fact(msg_enemy(h.cell, h.id, h.len, h.partial), 92, 2); // "one smells blood"
        else if (shared < 2)
        {
            int prio = 70;
            auto const q = fleet.find(queenId);
            if (AIM_REPORTS && me != queenId && q != fleet.end() && R - q->second.round <= 3 && manhattan(h.cell, q->second.cell) <= 14)
                prio = 88; // a threat to the queen goes out before anything else
            queue_fact(msg_enemy(h.cell, h.id, h.len, h.partial), prio, 1);
            shared++;
        }
    }
}

// ---------------------------------------------------------------------------
// Occupancy, flood fill and path finding
// ---------------------------------------------------------------------------
// Bodies are time-aware: the segment i places from the tail (tail = 0) is
// still there when the head tries to enter at step t < i + 2, because
// collision is checked before the tail moves. Other dragons get the same rule
// (plus one step of margin in case they eat) when their whole body is in view,
// and are solid otherwise.
std::vector<int> ownStamp, ownRel, wallStamp;
int stamp = 1, wstamp = 1;

void set_body(std::vector<int> const& b, int len)
{
    stamp++;
    for (int i = 0; i < static_cast<int>(b.size()); i++)
    {
        ownStamp[b[i]] = stamp;
        ownRel[b[i]] = (len - 1 - i) + 2;
    }
}

bool passable(int c, int t)
{
    if ((otherRel[c] && t < otherRel[c]) || wallStamp[c] == wstamp)
        return false;
    return ownStamp[c] != stamp || t >= ownRel[c];
}

struct FloodRes
{
    int area = 0;
    bool tail = false;
    bool frontier = false;
};

std::vector<int> bfsQ, bfsT, visStamp;
int vstamp = 1;
bool ignoreContested = false;

// Cells reachable from `start` using only edges we know are crossable.
FloodRes flood(int start, int tailCell, int cap)
{
    FloodRes r;
    vstamp++;
    bfsQ.clear();
    bfsT.clear();
    bfsQ.push_back(start);
    bfsT.push_back(0);
    visStamp[start] = vstamp;
    for (std::size_t i = 0; i < bfsQ.size() && r.area < cap; i++)
    {
        int const c = bfsQ[i], t = bfsT[i];
        for (int d = 0; d < 4; d++)
        {
            int const n = cross(c, d);
            if (n == -2)
            {
                r.frontier = true; // unexplored water beyond: count as open
                continue;
            }
            if (n < 0 || visStamp[n] == vstamp)
                continue;
            if (!passable(n, t + 1) || (t == 0 && contested[n] && !ignoreContested))
                continue;
            visStamp[n] = vstamp;
            r.area++;
            if (n == tailCell)
                r.tail = true;
            bfsQ.push_back(n);
            bfsT.push_back(t + 1);
        }
    }
    return r;
}

// Optimistic shortest paths for planning: unknown edges count as open, kelp and
// unlocated portals as closed, known portals as shortcuts.
std::vector<int> planSteps;
std::vector<std::vector<int>> planRing;

void plan_bfs(int start, std::vector<int>& dist)
{
    std::fill(dist.begin(), dist.end(), INF);
    if (UNKNOWN_EDGE_COST > 1)
    {
        // Dial's algorithm: known edges cost 1, edges nobody has seen cost
        // more (in a maze most of them turn out to be kelp). Bodies are still
        // timed by the number of steps, not by the cost.
        int const K = UNKNOWN_EDGE_COST + 1;
        planRing.resize(K);
        for (auto& b : planRing)
            b.clear();
        dist[start] = 0;
        planSteps[start] = 0;
        planRing[0].push_back(start);
        int pending = 1;
        for (int cost = 0; pending > 0; cost++)
        {
            auto& bk = planRing[cost % K];
            for (std::size_t i = 0; i < bk.size(); i++)
            {
                int const c = bk[i];
                if (dist[c] != cost)
                    continue;
                for (int d = 0; d < 4; d++)
                {
                    int n = cross(c, d);
                    int w = 1;
                    if (n == -2)
                    {
                        n = nb(c, d);
                        w = UNKNOWN_EDGE_COST;
                    }
                    int const nt = planSteps[c] + 1;
                    if (n < 0 || cost + w >= dist[n] || !passable(n, nt))
                        continue;
                    dist[n] = cost + w;
                    planSteps[n] = nt;
                    planRing[(cost + w) % K].push_back(n);
                    pending++;
                }
            }
            pending -= static_cast<int>(bk.size());
            bk.clear();
        }
        return;
    }
    bfsQ.clear();
    bfsQ.push_back(start);
    dist[start] = 0;
    for (std::size_t i = 0; i < bfsQ.size(); i++)
    {
        int const c = bfsQ[i];
        int const t = dist[c] + 1;
        for (int d = 0; d < 4; d++)
        {
            int n = cross(c, d);
            if (n == -2)
                n = nb(c, d);
            if (n < 0 || dist[n] != INF || !passable(n, t))
                continue;
            dist[n] = t;
            bfsQ.push_back(n);
        }
    }
}

// Distance to a cell, or to its nearest neighbour if the cell itself is
// occupied (used for enemy heads and teammates).
int dist_to(std::vector<int> const& dist, int target)
{
    if (dist[target] < INF)
        return dist[target];
    int best = INF;
    for (int d = 0; d < 4; d++)
        best = std::min(best, dist[nb(target, d)] + (dist[nb(target, d)] < INF ? 1 : 0));
    return best;
}

bool pearl_at(int c)
{
    return pearlState[c] == 1 && (vis[c] || R - pearlRound[c] <= 3);
}

// ---------------------------------------------------------------------------
// Fleet state: danger, transition, leaders, mode (sections 11-16)
// ---------------------------------------------------------------------------
Role role_for(int id)
{
    std::uint32_t const h = static_cast<std::uint32_t>(id) * 2654435761u;
    int const r = static_cast<int>((h >> 16) % 10);
    if (r < 3) return ROLE_COMBAT;
    if (r < 4) return ROLE_PORTAL;
    if (r < 6) return ROLE_EXPLORER;
    return ROLE_COLLECTOR;
}

// Fleet size the expansion phase aims for.
int expansion_target() { return std::min(unitLimit - 2, std::max(4, N / EXP_DENSITY)); }

void compute_fleet_state()
{
    int const head = body[0];
    std::unordered_set<int> recent;
    for (auto const& e : enemyReps)
        if (R - e.round <= 60)
            recent.insert(e.id);
    distinctEnemies = static_cast<int>(recent.size());

    // Section 12: more opponents around -> keep the big fleet for longer.
    int const d = distinctEnemies;
    int const thr = (d >= 12 ? 400 : d >= 7 ? 360 : d >= 3 ? 310 : d >= 1 ? 250 : 200) - TRANS_SHIFT;
    if (!transitioned)
        transitionRound = thr;
    if (!transitioned && R >= transitionRound)
        transitioned = true;

    localThreat = 0;
    std::unordered_set<int> counted;
    for (auto const& h : heads)
        if (!h.mine)
        {
            localThreat++;
            counted.insert(h.id);
        }
    for (auto const& e : enemyReps)
        if (R - e.round <= 6 && !counted.count(e.id) && manhattan(e.cell, head) <= 8)
        {
            localThreat++;
            counted.insert(e.id);
        }
    if (echoEnemy >= 2)
        localThreat++;

    // Expansion (numbers first): lasts until the fleet first reaches its
    // target. The queen splits too until QUEEN_GROW_ROUND; if the enemy queen
    // is still alive by then she grows instead (once it is dead, staying alive
    // is all that counts, so she keeps splitting while there is room).
    if (EXPANSION)
    {
        if (expansionPhase && (R >= EXP_END || units >= expansion_target()))
            expansionPhase = false;
        queenSplits = R < QUEEN_GROW_ROUND || enemyQueenDead;
    }
    else
        expansionPhase = queenSplits = false;

    // Hunters: a fixed share of the fleet (by id) goes after the enemy queen
    // once the opening is over. The queen and the leaders never hunt.
    {
        std::uint32_t const hh = static_cast<std::uint32_t>(me) * 2246822519u + 3266489917u;
        bool const active = HUNTERS && !(enemyQueenDead && !ourQueenDead) && (R >= HUNT_START || !expansionPhase);
        int const slot = static_cast<int>((hh >> 13) % 10);
        hunterSlot = !amQueen && slot < HUNTER_SHARE;
        isHunter = active && !amQueen && !isLeader && slot < HUNTER_SHARE;
        // Guards: their own slice of the fleet; once the enemy queen is dead
        // the hunters come home too.
        isGuard = GUARDS && !amQueen && !isLeader && !ourQueenDead && !isHunter &&
                  ((slot >= HUNTER_SHARE && slot < HUNTER_SHARE + GUARD_SHARE) || (enemyQueenDead && slot < HUNTER_SHARE)) &&
                  (GUARD_MIN_UNITS == 0 || enemyQueenDead || (units >= GUARD_MIN_UNITS && !expansionPhase));
        isScreen = SCREENS && isGuard && slot == HUNTER_SHARE;
        isDefender = OWN_HALF && !amQueen && !isLeader && !isGuard && !isHunter && slot == DEFENDER_SLOT && R >= HUNT_START;
    }

    // Too many leaders (they could not hear each other at election time):
    // step down if enough longer leaders are known.
    amQueen = me == queenId;
    if (amQueen)
        isLeader = true; // the queen leads for the whole game
    else if (isLeader)
    {
        int longer = 0;
        for (auto const& [id, s] : fleet)
            if (id != me && s.leader && R - s.round <= 30 && (s.len > L || (s.len == L && id < me)))
                longer++;
        if (longer >= LEADER_COUNT)
            isLeader = false;
    }

    // Leader election (section 11): the longest dragons we know of.
    if (transitioned && !expansionPhase && !isLeader && L >= 3)
    {
        int freshLeaders = 0;
        std::vector<std::pair<int, int>> ranking{{-L, me}};
        for (auto const& [id, s] : fleet)
        {
            if (id == me || R - s.round > 30)
                continue;
            if (s.leader)
                freshLeaders++;
            else
                ranking.push_back({-s.len, id});
        }
        int const slots = LEADER_COUNT - freshLeaders;
        std::sort(ranking.begin(), ranking.end());
        for (int i = 0; i < slots && i < static_cast<int>(ranking.size()); i++)
            if (ranking[i].second == me)
                isLeader = true;
    }

    // Heir: once the enemy queen is dead ours only has to live, and the
    // longest of the rest grows (insurance for the longest-dragon tiebreak).
    isHeir = false;
    if (HEIR && enemyQueenDead && !ourQueenDead && !amQueen)
    {
        isHeir = true;
        for (auto const& [id, s] : fleet)
            if (id != me && id != queenId && R - s.round <= 10 && (s.len > L || (s.len == L && id < me)))
                isHeir = false;
        if (isHeir)
            isLeader = true;
    }

    // Big open map late in the game: length decides the tiebreaks there and
    // long dragons do not trap themselves, so the fleet turns into length.
    // Small or kelp-dense maps keep their numbers.
    openMap = consolidate = false;
    if (N >= OPEN_MIN_CELLS)
    {
        int known = 0, kelp = 0;
        for (int code = 0; code < 2 * N; code++)
            if (edgeType[code] != E_UNK)
            {
                known++;
                kelp += edgeType[code] == E_KELP;
            }
        openMap = known > 0 && kelp <= OPEN_KELP_MAX * known;
        consolidate = CONSOLIDATE && openMap && R >= CONSOL_ROUND;
    }

    // Modes (sections 13-15).
    bool enemyNearby = false;
    for (auto const& e : enemyReps)
        if (R - e.round <= 30 && manhattan(e.cell, head) <= 12)
            enemyNearby = true;
    if (localThreat >= 2 || (localThreat >= 1 && role == ROLE_COMBAT))
        mode = MODE_COMBAT;
    else if (transitioned && !enemyNearby && localThreat == 0)
        mode = MODE_FARM;
    else if (transitioned)
        mode = MODE_PRESERVE;
    else
        mode = MODE_NORMAL;
}

// ---------------------------------------------------------------------------
// Target selection (sections 6-10, 18)
// ---------------------------------------------------------------------------
struct PearlCand
{
    int cell, appear;
    double conf;
};

std::vector<int> distHead, distTmp;
std::vector<int> skipPearl; // round until which this dragon ignores the pearl (only reachable at a loss)

// Our half: nearer our queen's start than its mirror image (theirs).
int enemy_spawn_guess()
{
    if (ourQueenSpawn < 0)
        return -1;
    if (symKnown >= 0)
        return mirror_cell(symKnown, ourQueenSpawn);
    for (int k = 0; k < 3; k++)
        if (symMask & (1 << k))
            return mirror_cell(k, ourQueenSpawn);
    return -1;
}
int halfMargin(int c) // > 0 on our side, < 0 on theirs
{
    int const es = enemy_spawn_guess();
    if (es < 0 || es == ourQueenSpawn)
        return 0;
    return manhattan(c, es) - manhattan(c, ourQueenSpawn);
}

int est_enemy_units()
{
    return std::max(distinctEnemies, 1);
}

// Implicit, communication-light assignment: every dragon solves the same
// greedy matching of known teammates to known pearls, so dragons split up
// instead of all chasing one pearl (sections 6, 7, 9).
int choose_pearl(std::vector<PearlCand> const& pearls)
{
    struct Agent
    {
        int id, cell, fixedEta;
        bool leader;
    };
    std::vector<Agent> agents{{me, body[0], -1, isLeader}};
    std::unordered_set<int> seen{me};
    for (auto const& h : heads)
        if (h.mine && !seen.count(h.id))
        {
            seen.insert(h.id);
            auto it = fleet.find(h.id);
            agents.push_back({h.id, h.cell, -1, it != fleet.end() && it->second.leader});
        }
    for (auto const& [id, s] : fleet)
        if (!seen.count(id) && R - s.round <= 4 && agents.size() < 24)
        {
            seen.insert(id);
            agents.push_back({id, s.cell, -1, s.leader});
        }

    struct Pair
    {
        double cost;
        int agent, pearl;
    };
    std::vector<Pair> pairs;
    for (int pi = 0; pi < static_cast<int>(pearls.size()); pi++)
    {
        auto const& p = pearls[pi];
        auto const cl = claims.find(p.cell);
        for (int ai = 0; ai < static_cast<int>(agents.size()); ai++)
        {
            auto const& a = agents[ai];
            int eta;
            if (a.id == me)
                eta = distHead[p.cell];
            else if (cl != claims.end() && cl->second.id == a.id)
                eta = std::max(0, cl->second.eta - (R - cl->second.round));
            else
                eta = manhattan(a.cell, p.cell);
            if (eta >= INF)
                continue;
            double cost = std::max(eta, p.appear - R) + 1.0;
            cost /= p.conf;
            if (a.leader)
                cost *= a.id == queenId ? (EXPANSION && queenSplits ? 1.0 : 0.3) : 0.6; // feed the queen (once she grows), then the leaders
            pairs.push_back({cost + a.id * 1e-7, ai, pi});
        }
        // A teammate we cannot see but who claimed this pearl still counts.
        if (cl != claims.end() && !seen.count(cl->second.id))
        {
            double const cost = std::max(0, cl->second.eta - (R - cl->second.round)) + 1.0;
            pairs.push_back({cost / p.conf, -1, pi});
        }
    }
    std::sort(pairs.begin(), pairs.end(), [](Pair const& a, Pair const& b) { return a.cost < b.cost; });
    std::vector<char> agentUsed(agents.size(), 0), pearlUsed(pearls.size(), 0);
    for (auto const& pr : pairs)
    {
        if (pearlUsed[pr.pearl] || (pr.agent >= 0 && agentUsed[pr.agent]))
            continue;
        pearlUsed[pr.pearl] = 1;
        if (pr.agent < 0)
            continue;
        agentUsed[pr.agent] = 1;
        if (agents[pr.agent].id == me)
            return pr.pearl;
    }
    return -1;
}

std::vector<PearlCand> gather_pearls()
{
    std::vector<PearlCand> out;
    for (int c = 0; c < N; c++)
    {
        if (vis[c] && occId[c] >= 0)
            continue;
        double conf = 0;
        int appear = R;
        if (pearlState[c] == 1)
            conf = vis[c] ? 1.0 : std::max(0.2, 0.9 - 0.02 * (R - pearlRound[c]));
        else if (pearlState[c] == 2)
            conf = std::max(0.15, 0.55 - 0.01 * (R - pearlRound[c]));
        else if (nextSpawn[c] >= R && nextSpawn[c] - R <= std::max(25, (distHead[c] < INF ? distHead[c] : 0) + PREPOS_SLACK))
        {
            conf = nextEst[c] ? 0.35 : CAMP_CONF;
            appear = nextSpawn[c];
        }
        if (conf <= 0 || distHead[c] >= INF || skipPearl[c] > R)
            continue;
        int const eta = distHead[c];
        if (eta > 60)
            continue;
        // Contested: an enemy head is clearly closer.
        for (auto const& h : heads)
            if (!h.mine && manhattan(h.cell, c) + 1 < eta)
                conf *= (AGGRO_EXPANSION && expansionPhase && !amQueen) ? 0.8 : 0.35;
        if (OWN_HALF && halfMargin(c) > 0)
            conf *= OWN_HALF_BONUS; // ours first: raiders feed on what we leave
        // The queen leaves pearls near recently reported enemies to others.
        if (amQueen)
            for (auto const& e : enemyReps)
                if (R - e.round <= 10 && manhattan(e.cell, c) <= 6)
                {
                    conf *= 0.25;
                    break;
                }
        // Dangerous area reported by the fleet.
        for (auto const& dg : dangers)
            if (dg.cause == 1 && R - dg.round <= 20 && manhattan(dg.cell, c) <= 3)
                conf *= isLeader ? 0.3 : 0.7;
        out.push_back({c, appear, conf});
    }
    if (out.size() > 60)
    {
        std::nth_element(out.begin(), out.begin() + 60, out.end(), [](PearlCand const& a, PearlCand const& b) {
            return std::max(distHead[a.cell], a.appear - R) / a.conf < std::max(distHead[b.cell], b.appear - R) / b.conf;
        });
        out.resize(60);
    }
    return out;
}

// Section 9: spread out. Unseen cells first, then stale ones, away from teammates.
int choose_explore_goal()
{
    bool const valid = exploreGoal >= 0 && R - exploreSetRound < 40 && distHead[exploreGoal] < INF &&
                       exploreGoal != body[0] && (seenRound[exploreGoal] < exploreSetRound);
    if (valid)
        return exploreGoal;
    std::vector<int> teamCells;
    for (auto const& h : heads)
        if (h.mine)
            teamCells.push_back(h.cell);
    for (auto const& [id, s] : fleet)
        if (R - s.round <= 10)
            teamCells.push_back(s.cell);

    int best = -1;
    double bestScore = 1e18;
    for (int pass = amQueen ? 1 : 0; pass < 2 && best < 0; pass++)
        for (int i = 0; i < 48; i++)
        {
            int const c = static_cast<int>(rng() % static_cast<unsigned>(N));
            bool const unseen = seenRound[c] < 0;
            if (pass == 0 && !unseen)
                continue;
            if (pass == 1 && R - seenRound[c] < 25)
                continue;
            int const dh = distHead[c];
            if (dh >= INF || dh < 4)
                continue;
            int crowd = 0;
            for (int tc : teamCells)
                if (manhattan(tc, c) < 8)
                    crowd++;
            double score = dh + 25.0 * crowd;
            if (role == ROLE_EXPLORER)
                score -= 0.3 * dh; // explorers push further out
            for (auto const& dg : dangers)
                if (dg.cause == 1 && R - dg.round <= 30 && manhattan(dg.cell, c) <= 4)
                    score += isLeader ? 200 : 40;
            if (score < bestScore)
            {
                bestScore = score;
                best = c;
            }
        }
    exploreGoal = best;
    exploreSetRound = R;
    return best;
}

// Nearest spawn tile no teammate is already sitting by; sooner spawns first.
int choose_camp_goal(bool ownHalf = false)
{
    std::vector<int> mates;
    for (auto const& h : heads)
        if (h.mine && h.id != me)
            mates.push_back(h.cell);
    for (auto const& [id, s] : fleet)
        if (id != me && R - s.round <= 6)
            mates.push_back(s.cell);
    int best = -1;
    double bestScore = 1e18;
    for (int c = 0; c < N; c++)
    {
        if (nextSpawn[c] < 0 || distHead[c] >= 30 || skipPearl[c] > R)
            continue;
        bool taken = false;
        for (int m : mates)
            if (manhattan(m, c) <= 2)
                taken = true;
        if (taken)
            continue;
        double const wait = nextSpawn[c] >= R ? nextSpawn[c] - R : 15; // spawned earlier: next time unknown
        double score = distHead[c] + 0.5 * std::max(0.0, wait - distHead[c]);
        if (ownHalf)
        {
            int const hm = halfMargin(c);
            if (hm <= 0)
                continue;
            score += 0.7 * hm; // near the middle: where raiders come through
        }
        if (score < bestScore)
        {
            bestScore = score;
            best = c;
        }
    }
    return best;
}

// Section 5: nearest portal edge whose far side is still unknown.
int choose_portal_goal(int& portalDir)
{
    int best = -1, bestD = 30;
    portalDir = -1;
    for (int c = 0; c < N; c++)
    {
        if (distHead[c] >= bestD)
            continue;
        for (int d = 0; d < 4; d++)
            if (cross(c, d) == -3)
            {
                best = c;
                bestD = distHead[c];
                portalDir = d;
                break;
            }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Decision
// ---------------------------------------------------------------------------
struct Cand
{
    int d = 0, dest = -1;
    bool legal = false, blind = false, attack = false, eat = false;
    bool ok1 = false, ok2 = false;
    int area = 0;
    double dive = -1e9; // net segments won by entering a dead end (+0.5 if we get out whole); non-queens
    bool surv = false;  // queen: some way on through known or unexplored water
    int dt = INF;       // path distance to the target after this move
    bool noLoop = false; // queen (length <= 3): no free 2x2 reachable afterwards
    double score = -1e18;
    std::vector<int> nb1;
};

bool is_adjacent_enemy_head(int cell)
{
    for (auto const& h : heads)
        if (!h.mine && manhattan(h.cell, cell) <= 1)
            return true;
    return false;
}

// Can a child made of the rear `childLen` segments get out? Its head is my
// tail and it moves later this round; my front part stays where it is.
bool child_can_escape(int childLen)
{
    if (static_cast<int>(body.size()) < L)
        return true; // tail is out of view, well away from whatever traps the head
    std::vector<int> child(body.rbegin(), body.rbegin() + childLen);
    wstamp++;
    for (int i = 0; i < L - childLen; i++)
        wallStamp[body[i]] = wstamp;
    set_body(child, childLen);
    FloodRes const f = flood(child[0], child.back(), childLen + 8);
    wstamp++;
    set_body(body, L);
    return f.tail || f.area >= std::min(childLen + 1, 6);
}

// Numbers are the goal, but a crowded map kills small dragons for nothing.
bool room_for_more()
{
    if (EXPANSION && R < EXP_END)
        return units < expansion_target();
    return units < std::min(unitLimit, std::max(2, N / SPLIT_DENSITY));
}

void act_move(Controller& ct, int d, char const* why)
{
    ct.make_move(dir_of(d));
    note = why;
    prevBody = body;
    lastDirs = {d};
}

void act_split(Controller& ct, int child, char const* why)
{
    ct.do_split(child);
    note = why;
    prevBody = body;
    lastDirs.clear();
}

// ---------------------------------------------------------------------------
// Queen survival search
// ---------------------------------------------------------------------------
// Area alone cannot tell a dead-end corridor from open water, and a snake
// cannot turn round in a corridor. So for the queen we look for any path of
// `need` further moves through known water. Body cells (set_body) free up
// over time; cells the head passes through stay occupied for `len` moves.
std::vector<int> pathStamp, pathTime;
int pstamp = 1, survNodes = 0;

bool survive_rec(int h, int t, int need, int len)
{
    if (t >= need || ++survNodes > SURV_NODE_CAP)
        return true; // long enough (or out of budget: assume fine)
    for (int d = 0; d < 4; d++)
    {
        int n = cross(h, d);
        if (n == -2)
        {
            if (SURV_UNKNOWN_SAFE)
                return true;
            // Unexplored edge: assume open water, but our own body (often out
            // of view on a long queen) and other dragons still block.
            n = nb(h, d);
        }
        if (n < 0)
            continue;
        int const nt = t + 1;
        if (!passable(n, nt) || (nt == 1 && contested[n]))
            continue;
        if (pathStamp[n] == pstamp && nt < pathTime[n] + len + 1)
            continue;
        int const saveS = pathStamp[n], saveT = pathTime[n];
        pathStamp[n] = pstamp;
        pathTime[n] = nt;
        bool const ok = survive_rec(n, nt, need, len);
        pathStamp[n] = saveS;
        pathTime[n] = saveT;
        if (ok)
            return true;
    }
    return false;
}

// b is the body after the move (head first), with its length.
bool queen_can_survive(std::vector<int> const& b, int len)
{
    set_body(b, len);
    pstamp++;
    survNodes = 0;
    pathStamp[b[0]] = pstamp;
    pathTime[b[0]] = 0;
    return survive_rec(b[0], 0, std::min(2 * len + 6, 50), len);
}

// Body after a sequence of steps (free steps only), or empty if a step is illegal.
std::vector<int> simulate_steps(std::vector<int> b, int len, std::vector<int> const& dirs, int& outLen)
{
    std::vector<int> eaten;
    for (int d : dirs)
    {
        int const n = cross(b[0], d);
        if (n < 0)
            return {};
        bool const eat = pearl_at(n) && std::find(eaten.begin(), eaten.end(), n) == eaten.end();
        if (eat)
            eaten.push_back(n);
        b.insert(b.begin(), n);
        if (eat)
            len++;
        else if (static_cast<int>(b.size()) > len)
            b.pop_back();
    }
    outLen = len;
    return b;
}

// ---------------------------------------------------------------------------
// Dead-end dives
// ---------------------------------------------------------------------------
// A dead end that holds pearls can still be worth entering when the pearls pay
// for the way out. At the bottom the survival split leaves the front two
// segments behind and the rest leaves as a child, whose head is our old tail
// outside the dead end. This searches our own moves through known water;
// other dragons keep their bodies. Value = net segments won.
int diveNodes = 0, diveCap = DIVE_NODE_CAP;

// After a split of all but the front 2 segments, can the child get away?
bool split_child_escapes(std::vector<int> const& b, int len)
{
    if (static_cast<int>(b.size()) < len)
        return true; // tail out of view, well away from the dead end
    int const childLen = len - 2;
    std::vector<int> child(b.rbegin(), b.rbegin() + childLen);
    wstamp++;
    for (int i = 0; i < len - childLen; i++)
        wallStamp[b[i]] = wstamp;
    set_body(child, childLen);
    FloodRes const f = flood(child[0], child.back(), childLen + 8);
    wstamp++;
    return f.tail || f.area >= std::min(childLen + 1, 6);
}

double dive_rec(std::vector<int> const& b, int len, int depth, int eaten, std::vector<int>& eatenCells)
{
    int const h = b[0];
    set_body(b, len);
    int const tailCell = static_cast<int>(b.size()) >= len ? b.back() : -1;
    FloodRes const f = flood(h, tailCell, 2 * len + 4);
    if (f.tail || f.area + (f.frontier ? len : 0) >= 2 * len + 4 || (FRONTIER_OPEN && !isLeader && f.frontier))
        return eaten + 0.5; // back in open water: everything eaten is profit, nobody lost
    if (depth >= DIVE_DEPTH || ++diveNodes > diveCap)
        return eaten - 3; // unresolved: assume the split and a bit more
    double best = -1e9;
    for (int d = 0; d < 4; d++)
    {
        int const n = cross(h, d);
        if (n < 0)
            continue;
        set_body(b, len);
        if (!passable(n, 1))
            continue;
        bool const eat = pearl_at(n) && std::find(eatenCells.begin(), eatenCells.end(), n) == eatenCells.end();
        std::vector<int> nb2;
        nb2.reserve(b.size() + 1);
        nb2.push_back(n);
        nb2.insert(nb2.end(), b.begin(), b.end());
        int const nl = len + (eat ? 1 : 0);
        if (!eat && static_cast<int>(b.size()) >= len)
            nb2.pop_back();
        if (eat)
            eatenCells.push_back(n);
        best = std::max(best, dive_rec(nb2, nl, depth + 1, eaten + (eat ? 1 : 0), eatenCells));
        if (eat)
            eatenCells.pop_back();
    }
    if (best > -1e9)
        return best;
    // Stuck: the survival split saves all but the front two segments.
    if (len >= 4 && units < unitLimit && split_child_escapes(b, len))
        return eaten - 2;
    return eaten - len;
}

// ---------------------------------------------------------------------------
// Sprints: the first ceil(L/4) steps of a turn are free.
// ---------------------------------------------------------------------------
int free_steps() { return (L + 3) / 4; }
int enemy_reach(HeadInfo const& h) { return std::max(1, (h.len + 3) / 4); }

struct SprintPlan
{
    std::vector<int> dirs;
    double value = -1e18;
    bool kill = false;
};

std::vector<int> distGoal;

// Danger of ending a turn on cell n: next to a teammate head, or where an
// enemy head can reach us (leaders assume the enemy sprints its free steps).
// Queen threat map: the fewest paid sprint steps an enemy needs to put its
// head on a cell (0 = within its free steps, INF = out of reach). A head-on
// kills both dragons whatever their lengths, and a dragon may sprint past its
// free steps by paying one segment per step down to length 2.
std::vector<int> qThreat, qThreatVis, thStamp, thDist, thQ;
std::vector<int> qThreatCnt, qMargin; // enemies able to reach a cell; steps beyond the nearest reach
int thS = 1;

// Cells an enemy at src can put its head on this turn (freeR free steps, up to
// maxR with paid ones). `cnt`/`margin` (optional) also count attackers and
// record how far beyond the reach a cell lies, up to QUEEN_MARGIN more steps.
void reach_bfs(int src, int freeR, int maxR, std::vector<int>& out, std::vector<int>* cnt = nullptr, std::vector<int>* margin = nullptr)
{
    thS++;
    thQ.clear();
    thQ.push_back(src);
    thStamp[src] = thS;
    thDist[src] = 0;
    int const lim = maxR + (margin ? QUEEN_MARGIN : 0);
    for (std::size_t i = 0; i < thQ.size(); i++)
    {
        int const c = thQ[i], dc = thDist[c];
        if (dc >= lim)
            continue;
        for (int k = 0; k < 4; k++)
        {
            int n = cross(c, k);
            if (n == -2)
                n = nb(c, k); // unexplored edge: assume the enemy can pass
            if (n < 0 || thStamp[n] == thS)
                continue;
            thStamp[n] = thS;
            thDist[n] = dc + 1;
            if (dc + 1 <= maxR)
            {
                out[n] = std::min(out[n], std::max(0, dc + 1 - freeR));
                if (cnt)
                    (*cnt)[n]++;
            }
            else if (margin)
                (*margin)[n] = std::min((*margin)[n], dc + 1 - maxR);
            if (vis[n] && occId[n] >= 0)
                continue; // a body: the enemy cannot go through it
            thQ.push_back(n);
        }
    }
}

void compute_queen_threat()
{
    std::fill(qThreat.begin(), qThreat.end(), INF);
    std::fill(qThreatVis.begin(), qThreatVis.end(), INF);
    std::fill(qThreatCnt.begin(), qThreatCnt.end(), 0);
    std::fill(qMargin.begin(), qMargin.end(), INF);
    std::vector<int>* cnt = QUEEN_HARD_THREAT ? &qThreatCnt : nullptr;
    std::vector<int>* mar = QUEEN_HARD_THREAT ? &qMargin : nullptr;
    std::unordered_set<int> seenIds;
    for (auto const& h : heads)
    {
        if (h.mine)
            continue;
        seenIds.insert(h.id);
        int const len = std::max(h.len, h.estLen);
        int const f = std::max(1, (len + 3) / 4);
        int const m = std::min(PAID_REACH_CAP, f + (PAID_REACH ? std::max(0, len - 2) : 0));
        reach_bfs(h.cell, f, f, qThreatVis);
        reach_bfs(h.cell, f, std::max(f, m), qThreat, cnt, mar);
    }
    // Enemies the fleet reported in the last two rounds: they may have moved
    // a free step or two since.
    for (auto const& e : enemyReps)
    {
        int const age = R - e.round;
        if (age < 1 || age > REP_MAX_AGE || seenIds.count(e.id))
            continue;
        int const el = std::max(e.len, e.estLen);
        int const f = std::max(1, (el + 3) / 4) * (age + 1);
        int const m = std::min(PAID_REACH_CAP, f + (PAID_REACH ? std::max(0, el - 2) : 0));
        reach_bfs(e.cell, f, std::max(f, m), qThreat, cnt, mar);
    }
}

// Path distances from the queen's head out to `maxR` steps (known water;
// unexplored edges count as open). Used by teammates to give her room.
std::vector<int> qDist;
void queen_dist_bfs(int src, int maxR)
{
    std::fill(qDist.begin(), qDist.end(), INF);
    thQ.clear();
    thQ.push_back(src);
    qDist[src] = 0;
    for (std::size_t i = 0; i < thQ.size(); i++)
    {
        int const c = thQ[i];
        if (qDist[c] >= maxR)
            continue;
        for (int k = 0; k < 4; k++)
        {
            int n = cross(c, k);
            if (n == -2)
                n = nb(c, k);
            if (n < 0 || qDist[n] != INF)
                continue;
            qDist[n] = qDist[c] + 1;
            thQ.push_back(n);
        }
    }
}

// Open sides of a cell (kelp and unexplored edges excluded): <= 2 is a corridor.
int open_sides(int c)
{
    int k = 0;
    for (int d = 0; d < 4; d++)
        k += cross(c, d) >= 0;
    return k;
}

double queen_threat_pen(int n)
{
    if (!QUEEN_HARD_THREAT)
    {
        if (qThreat[n] == 0)
            return 3e6;
        if (qThreat[n] < INF)
            return PAID_THREAT_PEN / static_cast<double>(qThreat[n]);
        return 0;
    }
    // Every enemy moves after the queen, and a head-on kills both whatever the
    // lengths, so paying segments to reach her is free for the attacker:
    // anything within free + paid reach is as good as a kill.
    double p = 0;
    if (qThreat[n] == 0)
        p = 3e6;
    else if (qThreat[n] < INF)
        p = HARD_THREAT_PEN - 20000.0 * std::min(qThreat[n], 10);
    if (qThreatCnt[n] > 1)
        p += THREAT_EXTRA_ATTACKER * (qThreatCnt[n] - 1);
    if (qThreat[n] == INF && qMargin[n] <= QUEEN_MARGIN)
        p += QUEEN_MARGIN_PEN * (QUEEN_MARGIN + 1 - qMargin[n]);
    return p;
}

double end_threat(int n)
{
    double t = 0;
    for (auto const& hh : heads)
    {
        if (hh.mine)
        {
            if (manhattan(hh.cell, n) <= 1)
                t += 4000;
            continue;
        }
        if (amQueen && QUEEN_THREAT_MAP)
            continue; // added once below from the threat map
        int const reach = isLeader ? enemy_reach(hh) : 1;
        if (manhattan(hh.cell, n) <= reach)
            t += amQueen ? 3e6 : isLeader ? 300000 : THREAT_PEN;
    }
    if (amQueen && QUEEN_THREAT_MAP)
        t += queen_threat_pen(n);
    if (isLeader)
        for (int tc : enemyTails)
            if (manhattan(tc, n) <= 1)
                t += amQueen ? 400000 : 100000;
    return t;
}

int queen_exits(int qh, std::vector<int> const& newBody);

// Depth-first search over step sequences through cells in view. Other dragons
// do not move during our turn, so what we see is exact; our own body shifts
// step by step. Steps past freeN cost a segment each.
void sprint_dfs(std::vector<int> const& b, int len, int step, int maxSteps, int freeN, int eaten,
                std::vector<int>& dirs, std::vector<int>& eatenCells, bool useGoal, int goalStart, SprintPlan& best)
{
    int const h = b[0];
    for (int d = 0; d < 4; d++)
    {
        int const n = cross(h, d);
        if (n < 0 || !vis[n])
            continue;
        if (occId[n] >= 0 && occId[n] != me)
        {
            // Head-on with the enemy queen: worth any non-queen dragon.
            bool const canPay = step + 1 <= freeN || len >= 3;
            if (canPay && occHead[n] && occId[n] == enemyQueenId && !occMine[n] && !amQueen && !enemyQueenDead && !best.kill)
            {
                dirs.push_back(d);
                best.dirs = dirs;
                best.kill = true;
                best.value = 1e12;
                dirs.pop_back();
            }
            continue;
        }
        set_body(b, len);
        if (!passable(n, 1))
            continue;
        bool const eat = pearl_at(n) && std::find(eatenCells.begin(), eatenCells.end(), n) == eatenCells.end();
        std::vector<int> nb2;
        nb2.reserve(b.size() + 1);
        nb2.push_back(n);
        nb2.insert(nb2.end(), b.begin(), b.end());
        int nl = len + (eat ? 1 : 0);
        if (!eat && static_cast<int>(b.size()) >= len)
            nb2.pop_back();
        if (step + 1 > freeN) // a paid step also removes one more tail segment
        {
            if (static_cast<int>(nb2.size()) >= nl)
                nb2.pop_back();
            nl--;
            if (nl < 2)
                continue;
        }
        if (eat)
            eatenCells.push_back(n);
        dirs.push_back(d);
        int const eatenNow = eaten + (eat ? 1 : 0);
        if (step + 1 >= 2 && !best.kill)
        {
            int const tailCell = static_cast<int>(nb2.size()) >= nl ? nb2.back() : -1;
            set_body(nb2, nl);
            int const cap = std::min(N, 3 * nl + 24);
            FloodRes const f = flood(n, tailCell, cap);
            int const area = f.area + (f.frontier && !amQueen ? nl : 0);
            if (f.tail || area >= 2 * nl + 4)
            {
                double v = eatenNow * 3000.0 + std::min(area, cap) * 15.0 - (L + eatenNow - nl) * 4000.0 - end_threat(n);
                if (QUEEN_EXIT_GUARD && !amQueen)
                    for (auto const& qh : heads)
                        if (qh.mine && qh.id == queenId && manhattan(qh.cell, n) <= 2)
                        {
                            std::vector<int> nowBody(body.begin(), body.begin() + std::min<int>(body.size(), L));
                            std::vector<int> after(nb2.begin(), nb2.begin() + std::min<int>(nb2.size(), nl));
                            int const before = queen_exits(qh.cell, nowBody), now = queen_exits(qh.cell, after);
                            if (now < before && now < 2)
                                v -= QUEEN_EXIT_PEN; // a sprint must not end in the queen's last way out
                        }
                if (useGoal && distGoal[n] < INF)
                    v += 150.0 * (goalStart - distGoal[n]);
                if (v > best.value)
                {
                    best.value = v;
                    best.dirs = dirs;
                }
            }
        }
        if (step + 1 < maxSteps && !best.kill)
            sprint_dfs(nb2, nl, step + 1, maxSteps, freeN, eatenNow, dirs, eatenCells, useGoal, goalStart, best);
        dirs.pop_back();
        if (eat)
            eatenCells.pop_back();
    }
}

void act_moves(Controller& ct, std::vector<int> const& dirs, char const* why)
{
    std::vector<Direction> ds;
    for (int d : dirs)
        ds.push_back(dir_of(d));
    ct.make_moves(ds);
    note = why;
    prevBody = body;
    lastDirs = dirs;
}

// Best guess of the enemy queen's head: in view, recently reported, or the
// mirror image of our queen's start (one guess per symmetry still possible).
// Their feeders die next to their queen: three or more recent death drops
// close together (and not ours) mark where she probably is.
int feeder_queen_guess()
{
    if (!FEEDER_TRAIL || R < 100)
        return -1;
    std::vector<int> ev;
    for (auto const& e : dropEv)
    {
        if (R - e.round > 20 || e.nearOurQueen)
            continue;
        bool ours = false; // one of our dragons died there (a trade or an accident)
        for (auto const& dg : dangers)
            if (std::abs(dg.round - e.round) <= 3 && manhattan(dg.cell, e.cell) <= 3)
                ours = true;
        if (!ours)
            ev.push_back(e.cell);
    }
    int best = -1, bestCnt = 2;
    for (int a : ev)
    {
        int cnt = 0;
        for (int b : ev)
            if (b != a && manhattan(a, b) <= 5)
                cnt++;
        if (cnt >= bestCnt)
        {
            bestCnt = cnt;
            best = a;
        }
    }
    return best;
}

int enemy_queen_target()
{
    for (auto const& h : heads)
        if (!h.mine && h.id == enemyQueenId)
            return h.cell;
    int best = -1, bestRound = -1;
    for (auto const& e : enemyReps)
        if (e.id == enemyQueenId && R - e.round <= 30 && e.round > bestRound)
        {
            best = e.cell;
            bestRound = e.round;
        }
    if (best >= 0)
        return best;
    int const trail = feeder_queen_guess();
    if (trail >= 0)
        return trail;
    if (ourQueenSpawn < 0)
        return -1;
    std::vector<int> ks;
    for (int k = 0; k < 3; k++)
        if (symMask & (1 << k))
            ks.push_back(k);
    if (ks.empty())
        return -1;
    return mirror_cell(ks[me % ks.size()], ourQueenSpawn);
}

// Screen post: a cell SCREEN_MIN..SCREEN_MAX steps from the queen along her
// row (even ids) or column (odd ids), on the side nearer the enemy queen.
// Sonar runs along rows and columns, so from there a ping reaches her.
int screen_post(int qCell)
{
    int const eq = enemy_queen_target();
    int best = -1, bestScore = INF;
    bool const row = (me & 1) == 0;
    for (int off = -SCREEN_MAX; off <= SCREEN_MAX; off++)
    {
        if (std::abs(off) < SCREEN_MIN)
            continue;
        int const x = qCell % W, y = qCell / W;
        int const nx = row ? ((x + off) % W + W) % W : x, ny = row ? y : ((y + off) % H + H) % H;
        int const c = cell_of(nx, ny);
        if (distHead[c] >= INF || manhattan(c, qCell) < SCREEN_MIN)
            continue;
        int const sc = (eq >= 0 ? 4 * manhattan(c, eq) : 0) + distHead[c];
        if (sc < bestScore)
        {
            bestScore = sc;
            best = c;
        }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Bunker: once the enemy queen is dead, ours only has to stay alive. A queen
// of length 2-3 can circle a 2x2 box for ever (verified in the engine; at
// length 4 her own tail blocks the loop). Boxes with few open sides are safer.
// ---------------------------------------------------------------------------
int bunkerBox = -1;

// The box with top-left tl, in loop order (tl, east, south-east, south), when
// all four links inside it are known open water.
bool box_cells(int tl, std::array<int, 4>& out)
{
    auto const open = [](int c, int d) { return edgeType[edge_code(c, d)] == E_OPEN; };
    if (!open(tl, 1) || !open(tl, 2))
        return false;
    int const e = nb(tl, 1), s = nb(tl, 2), se = nb(e, 2);
    if (!open(e, 2) || !open(s, 1) || se == tl || e == s)
        return false;
    out = {tl, e, se, s};
    return true;
}

// Ways into the box from outside (unexplored edges count as open).
int box_exposure(std::array<int, 4> const& bx)
{
    int k = 0;
    for (int c : bx)
        for (int d = 0; d < 4; d++)
        {
            int const n = cross(c, d);
            if (n == -1 || std::find(bx.begin(), bx.end(), n) != bx.end())
                continue;
            k++;
        }
    return k;
}

// Usable now: no other dragon in it, not in enemy reach, and no pearl in it or
// due there (eating fills the box: a queen of length 4 in a 2x2 has no move).
bool box_usable(std::array<int, 4> const& bx)
{
    for (int c : bx)
    {
        if (vis[c] && occId[c] >= 0 && occId[c] != me)
            return false;
        if (qThreat[c] < INF)
            return false;
        if (pearlState[c] == 1 || obsNext[c] >= 0)
            return false;
        for (int k = 0; k < 4; k++)
        {
            std::uint8_t const t = edgeType[edge_code(c, k)];
            if (t != E_OPEN && t != E_KELP)
                return false; // no portals or unexplored edges around the bunker
        }
    }
    return true;
}

// A queen can never be trapped while she can reach a free loop longer than
// she is: she can circle it for ever and turn round there (a 2x2 for length
// <= 3, verified in the engine; a k x k ring holds 4(k-1) cells). Unexplored
// edges do not count here: pockets with unseen walls are how queens die.
bool ring_free(int tl, int k)
{
    std::vector<int> ring;
    int c = tl;
    int const dirs[4] = {1, 2, 3, 0}; // E along the top, S down the right, W along the bottom, N up the left
    for (int side = 0; side < 4; side++)
        for (int i = 0; i < k - 1; i++)
        {
            ring.push_back(c);
            if (edgeType[edge_code(c, dirs[side])] != E_OPEN)
                return false;
            c = nb(c, dirs[side]);
        }
    if (c != tl)
        return false;
    for (int x : ring)
        if ((vis[x] && occId[x] >= 0 && occId[x] != me) || wallStamp[x] == wstamp)
            return false;
    return true;
}

bool loop_reachable(std::vector<int> const& b, int len)
{
    int k = 2;
    while (4 * (k - 1) <= len)
        k++;
    if (k > 5)
        return true; // very long queens: no ring test (rare)
    set_body(b, len);
    std::unordered_map<int, int> dist{{b[0], 0}};
    std::vector<int> q{b[0]};
    for (std::size_t i = 0; i < q.size(); i++)
    {
        int const c = q[i], dc = dist[c];
        if (ring_free(c, k))
            return true;
        if (dc >= QUEEN_LOOP_DEPTH)
            continue;
        for (int d = 0; d < 4; d++)
        {
            if (edgeType[edge_code(c, d)] != E_OPEN)
                continue;
            int const n = nb(c, d);
            if (dist.count(n) || !passable(n, dc + 1))
                continue;
            dist[n] = dc + 1;
            q.push_back(n);
        }
    }
    return false;
}

// Optional queen split: does she still have a loop with the child's body (the
// tail part) standing where it is?
bool split_keeps_loop(int child)
{
    if (!QUEEN_LOOP_SAFE || static_cast<int>(body.size()) < L)
        return true;
    std::vector<int> front(body.begin(), body.begin() + (L - child));
    wstamp++;
    for (int i = L - child; i < L; i++)
        wallStamp[body[i]] = wstamp;
    bool const ok = loop_reachable(front, L - child);
    wstamp++;
    set_body(body, L);
    return ok;
}

int choose_bunker()
{
    int best = -1;
    double bestS = 1e18;
    std::array<int, 4> bx{};
    for (int c = 0; c < N; c++)
    {
        if (distHead[c] > BUNKER_SEARCH && c != body[0])
            continue;
        if (!box_cells(c, bx) || !box_usable(bx))
            continue;
        int d = INF;
        for (int x : bx)
            d = std::min(d, x == body[0] ? 0 : distHead[x]);
        if (d >= INF)
            continue;
        double sc = 8.0 * box_exposure(bx) + d;
        for (int x : bx)
            if (qMargin[x] <= QUEEN_MARGIN)
                sc += 6.0 * (QUEEN_MARGIN + 1 - qMargin[x]);
        for (auto const& e : enemyReps)
            if (R - e.round <= 10)
                sc += 40.0 / (1 + manhattan(e.cell, c));
        if (sc < bestS)
        {
            bestS = sc;
            best = c;
        }
    }
    return best;
}

// ---------------------------------------------------------------------------
// Packs: hunters (and, once our queen is dead, every small dragon) share out
// prey the same way pearls are shared: every dragon solves the same greedy
// matching from what the fleet knows, so packs form without negotiation.
// ---------------------------------------------------------------------------
int hunter_slot(int id)
{
    std::uint32_t const hh = static_cast<std::uint32_t>(id) * 2246822519u + 3266489917u;
    return static_cast<int>((hh >> 13) % 10);
}

bool hunts_now()
{
    return HUNTERS && !(enemyQueenDead && !ourQueenDead) && (R >= HUNT_START || !expansionPhase);
}

// Would teammate `id` (length len) be in a pack right now?
bool pack_member(int id, int len, bool leader)
{
    if (id == queenId || leader)
        return false;
    if (ENDGAME_PACKS && ourQueenDead && len <= 6)
        return true;
    return hunts_now() && hunter_slot(id) < HUNTER_SHARE && len >= HUNTER_LEN;
}

struct Prey
{
    int cell, id, len;
    bool queen;
};
std::vector<Prey> preyList;
int myPrey = -1, myPackSize = 0;

void assign_prey()
{
    preyList.clear();
    myPrey = -1;
    myPackSize = 0;
    int const qt = enemyQueenDead ? -1 : enemy_queen_target();
    if (qt >= 0)
        preyList.push_back({qt, enemyQueenId, 0, true});
    // Long enemy dragons: when the queens no longer decide the game, or while
    // nobody knows where the enemy queen is.
    if (ourQueenDead || enemyQueenDead || qt < 0)
        for (auto const& e : enemyReps)
            if (e.id != enemyQueenId && R - e.round <= 6 && e.len >= PREY_MIN_LEN)
                preyList.push_back({e.cell, e.id, e.len, false});
    if (preyList.empty())
        return;

    struct Agent
    {
        int id, cell;
    };
    std::vector<Agent> agents{{me, body[0]}};
    for (auto const& [id, st] : fleet)
        if (id != me && R - st.round <= 4 && pack_member(id, st.len, st.leader))
            agents.push_back({id, st.cell});
    struct Pair
    {
        double cost;
        int a, p;
    };
    std::vector<Pair> pairs;
    for (int pi = 0; pi < static_cast<int>(preyList.size()); pi++)
        for (int ai = 0; ai < static_cast<int>(agents.size()); ai++)
        {
            int const d = agents[ai].id == me ? dist_to(distHead, preyList[pi].cell) : manhattan(agents[ai].cell, preyList[pi].cell);
            if (d >= INF)
                continue;
            double const c = d - (preyList[pi].queen ? 8.0 : 0.25 * preyList[pi].len) + agents[ai].id * 1e-6;
            pairs.push_back({c, ai, pi});
        }
    std::sort(pairs.begin(), pairs.end(), [](Pair const& x, Pair const& y) { return x.cost < y.cost; });
    std::vector<int> taken(preyList.size(), 0);
    std::vector<char> used(agents.size(), 0);
    for (auto const& pr : pairs)
    {
        int const cap = preyList[pr.p].queen ? 1000 : PACK_SIZE;
        if (used[pr.a] || taken[pr.p] >= cap)
            continue;
        used[pr.a] = 1;
        taken[pr.p]++;
        if (agents[pr.a].id == me)
            myPrey = pr.p;
    }
    if (myPrey >= 0)
        myPackSize = taken[myPrey];
}

// Pack mates (other than us) within `r` of a cell, from fleet reports.
int mates_near(int cell, int r)
{
    int k = 0;
    for (auto const& [id, st] : fleet)
        if (id != me && R - st.round <= 3 && pack_member(id, st.len, st.leader) && manhattan(st.cell, cell) <= r)
            k++;
    return k;
}

// Shortest step sequence that ends in the enemy queen's head. Other dragons
// stand still during our turn; our own body follows us. Steps past the free
// ones cost a segment each, which does not matter: a head-on kills us anyway.
std::vector<int> regicide_path(int qcell, int maxSteps)
{
    set_body(body, L);
    std::unordered_map<int, int> dist, par, pdir;
    std::vector<int> q{body[0]};
    dist[body[0]] = 0;
    for (std::size_t i = 0; i < q.size(); i++)
    {
        int const c = q[i], dc = dist[c];
        if (dc >= maxSteps)
            continue;
        for (int d = 0; d < 4; d++)
        {
            int const n = cross(c, d);
            if (n < 0 || dist.count(n))
                continue;
            if (n == qcell)
            {
                std::vector<int> dirs{d};
                for (int x = c; x != body[0]; x = par[x])
                    dirs.push_back(pdir[x]);
                std::reverse(dirs.begin(), dirs.end());
                return dirs;
            }
            if (!vis[n] || (occId[n] >= 0 && occId[n] != me) || !passable(n, dc + 1))
                continue;
            dist[n] = dc + 1;
            par[n] = c;
            pdir[n] = d;
            q.push_back(n);
        }
    }
    return {};
}

// Free cells next to the queen's head for her next move, with our body as it
// will be after a candidate move (newBody, head first; empty = as now).
int queen_exits(int qh, std::vector<int> const& newBody)
{
    int k = 0;
    for (int d = 0; d < 4; d++)
    {
        int n = cross(qh, d);
        if (n == -2)
            n = nb(qh, d); // unexplored: may be open
        if (n < 0)
            continue;
        if (vis[n] && occId[n] >= 0 && occId[n] != me)
            continue; // another dragon (or her own body) is there
        if (std::find(newBody.begin(), newBody.end(), n) != newBody.end())
            continue; // we will be there
        k++;
    }
    return k;
}

// Running guess of the round-500 tiebreaks: queen length, then longest
// dragon, then total length. -1 = unknown.
struct TieState
{
    int ourQ = -1, theirQ = -1, ourLong = 0, theirLong = -1;
};
TieState tie_state()
{
    TieState t;
    if (ourQueenDead)
        t.ourQ = 0;
    else if (me == queenId)
        t.ourQ = L;
    else if (auto const q = fleet.find(queenId); q != fleet.end() && R - q->second.round <= 60)
        t.ourQ = q->second.len;
    if (enemyQueenDead)
        t.theirQ = 0;
    else if (auto const e = enemyLenMem.find(enemyQueenId); e != enemyLenMem.end() && R - e->second.round <= 150)
        t.theirQ = e->second.len;
    t.ourLong = L;
    for (auto const& [id, st] : fleet)
        if (R - st.round <= 60)
            t.ourLong = std::max(t.ourLong, st.len);
    for (auto const& [id, lm] : enemyLenMem)
        if (R - lm.round <= 100)
            t.theirLong = std::max(t.theirLong, lm.len);
    return t;
}

// Giant (insurance for the longest-dragon tiebreak): our longest non-queen
// leader we know of, -1 if none.
int giant_id()
{
    int best = -1, bestLen = 0;
    if (isLeader && !amQueen)
    {
        best = me;
        bestLen = L;
    }
    for (auto const& [id, st] : fleet)
        if (id != queenId && st.leader && R - st.round <= 30 && (st.len > bestLen || (st.len == bestLen && id < best)))
        {
            best = id;
            bestLen = st.len;
        }
    return best;
}

void decide(Controller& ct)
{
    int const head = body[0];
    int const facing = dir_index(ct.get_dir());
    claimTarget = -1;
    if (amQueen && ourQueenSpawn < 0)
        ourQueenSpawn = head;
    // First look: is the queen in a pocket that kelp closes off inside her
    // view, with no portal? A split child there could never get out, so she
    // keeps her length and just circles (she needs one free cell to move).
    if (QUEEN_SEALED_NOSPLIT && amQueen && !sealedChecked)
    {
        sealedChecked = true;
        bool closed = true;
        std::vector<int> reg{head};
        std::unordered_set<int> inReg{head};
        for (std::size_t i = 0; i < reg.size() && closed; i++)
            for (int d = 0; d < 4 && closed; d++)
            {
                std::uint8_t const et = edgeType[edge_code(reg[i], d)];
                if (et == E_KELP)
                    continue;
                if (et != E_OPEN)
                {
                    closed = false; // portal or unexplored edge: not sealed
                    break;
                }
                int const n = nb(reg[i], d);
                if (!vis[n])
                {
                    closed = false; // the pocket runs out of view
                    break;
                }
                if (inReg.insert(n).second)
                    reg.push_back(n);
            }
        queenSealed = closed;
        sealedCells = closed ? static_cast<int>(reg.size()) : 0;
    }
    bool const sealedNoSplit = amQueen && queenSealed && L <= sealedCells - 1;
    if (ourQueenSpawn < 0 && R <= 1)
        for (auto const& h : heads)
            if (h.mine && h.id == queenId)
                ourQueenSpawn = h.cell;
    if (HUNTERS && ourQueenSpawn >= 0 && (R % 20 == me % 20 || (amQueen && R < 5)))
        queue_fact(msg_qspawn(ourQueenSpawn), amQueen ? 60 : 40, 1);
    if (EQ_DEATH_DETECT && enemyQueenDead && R % 8 == me % 8)
        queue_fact(msg_queen_dead(true), 55, 1); // keep telling: relays are lossy
    if (EQ_DEATH_DETECT && ourQueenDead && R % 8 == (me + 4) % 8)
        queue_fact(msg_queen_dead(false), 55, 1);

    if (amQueen && QUEEN_THREAT_MAP)
    {
        compute_queen_threat();
        for (int c = 0; c < N; c++)
            if (qThreatVis[c] == 0 && !(vis[c] && occId[c] >= 0))
                contested[c] = 1;
    }
    set_body(body, L);
    plan_bfs(head, distHead);

    // ---- Candidate moves ------------------------------------------------
    std::array<Cand, 4> cands;
    int const cap = std::min(N, 3 * L + 24);
    bool anyLegal = false, anySafe = false, attackAvail = false;
    int attackDir = -1, attackLen = 0;
    for (int d = 0; d < 4; d++)
    {
        Cand& cd = cands[d];
        cd.d = d;
        int const dest = cross(head, d);
        cd.dest = dest;
        if (dest == -1 || dest == -2)
            continue;
        if (dest == -3)
        {
            cd.legal = true;
            cd.blind = true;
            anyLegal = true;
            continue;
        }
        if (vis[dest] && occId[dest] >= 0 && occId[dest] != me)
        {
            if (occHead[dest] && !occMine[dest])
            {
                cd.attack = true;
                attackAvail = true;
                attackDir = d;
                for (auto const& h : heads)
                    if (h.cell == dest)
                        attackLen = h.len;
            }
            continue;
        }
        if (!passable(dest, 1) || (vis[dest] && occId[dest] == me))
            continue;
        cd.legal = true;
        anyLegal = true;
        cd.eat = pearl_at(dest);
        std::vector<int> nb1;
        nb1.reserve(body.size() + 1);
        nb1.push_back(dest);
        nb1.insert(nb1.end(), body.begin(), body.end());
        int const nl = L + (cd.eat ? 1 : 0);
        if (!cd.eat && static_cast<int>(body.size()) >= L)
            nb1.pop_back();
        int const tailCell = static_cast<int>(nb1.size()) >= nl ? nb1.back() : -1;
        set_body(nb1, nl);
        FloodRes f1 = flood(dest, tailCell, cap);
        cd.area = f1.area + (f1.frontier && !amQueen ? nl : 0); // the queen trusts only known water
        // A snake cannot turn round in a corridor, so raw area is only trusted
        // when there is room to circle; reaching our own tail is always an exit.
        bool const frontierExit = FRONTIER_OPEN && !isLeader; // small dragons may explore narrow passages
        cd.ok1 = f1.tail || cd.area >= 2 * nl + 4 || (frontierExit && f1.frontier);

        // Depth 2: is there a follow-up that keeps us free?
        for (int d2 = 0; d2 < 4 && !cd.ok2; d2++)
        {
            int const n2 = cross(dest, d2);
            if (n2 < 0)
                continue;
            set_body(nb1, nl);
            if (!passable(n2, 1) || contested[n2] || (vis[n2] && occId[n2] == me && ownStamp[n2] != stamp))
                continue;
            bool const eat2 = pearl_at(n2);
            std::vector<int> nb2{n2};
            nb2.insert(nb2.end(), nb1.begin(), nb1.end());
            int const nl2 = nl + (eat2 ? 1 : 0);
            if (!eat2 && static_cast<int>(nb1.size()) >= nl)
                nb2.pop_back();
            int const tail2 = static_cast<int>(nb2.size()) >= nl2 ? nb2.back() : -1;
            set_body(nb2, nl2);
            FloodRes const f2 = flood(n2, tail2, cap);
            if (f2.tail || f2.area + (f2.frontier && !amQueen ? nl2 : 0) >= 2 * nl2 + 2 || (frontierExit && f2.frontier))
                cd.ok2 = true;
        }
        if (amQueen && cd.ok2 && !queen_can_survive(nb1, nl))
            cd.ok1 = cd.ok2 = false; // a corridor with no way back
        if (QUEEN_LOOP_SAFE && amQueen)
            cd.noLoop = !loop_reachable(nb1, nl);
        if (cd.ok2)
            anySafe = true;
        cd.nb1 = std::move(nb1);
    }
    // Dead ends with pearls (non-queens): worth it when the pearls pay for
    // the survival split at the bottom (the user's compensation rule).
    double bestDive = -1e9;
    // Each dive node floods ~2L+4 cells, so the node budget shrinks with
    // length: a long dragon costs no more per candidate than a short one.
    diveCap = DIVE_NODE_CAP * 12 / std::max(12, 2 * L + 4);
    if (DIVE_ENABLE && !amQueen)
        for (auto& cd : cands)
            if (cd.legal && !cd.blind && !cd.ok1 && !cd.nb1.empty() && !contested[cd.dest])
            {
                diveNodes = 0;
                std::vector<int> ec;
                if (cd.eat)
                    ec.push_back(cd.dest);
                cd.dive = dive_rec(cd.nb1, L + (cd.eat ? 1 : 0), 1, cd.eat ? 1 : 0, ec);
                bestDive = std::max(bestDive, cd.dive);
            }
    bool const diving = bestDive >= DIVE_MIN_GAIN;
    // The queen with no safe move: still tell a corridor that leads on from a
    // known dead end (unexplored water counts as a way on here).
    if (QUEEN_SURV_RANK && amQueen && !anySafe)
        for (auto& cd : cands)
            if (cd.legal && !cd.blind && !cd.nb1.empty())
            {
                ignoreContested = false;
                std::vector<int> const& b1 = cd.nb1;
                set_body(b1, L + (cd.eat ? 1 : 0));
                pstamp++;
                survNodes = 0;
                pathStamp[b1[0]] = pstamp;
                pathTime[b1[0]] = 0;
                int const len1 = L + (cd.eat ? 1 : 0);
                cd.surv = survive_rec(b1[0], 0, std::min(2 * len1 + 6, 50), len1);
            }
    set_body(body, L);
#ifdef FLEET_DEBUG
    {
        std::string dbg = "head " + std::to_string(head % W) + "," + std::to_string(head / W) + " body" + std::to_string(body.size()) + "/" + std::to_string(L);
        for (auto const& cd : cands)
        {
            int const code = edge_code(head, cd.d);
            dbg += std::string(" ") + DCH[cd.d] + ":dest" + std::to_string(cd.dest) + " et" + std::to_string(edgeType[code]) +
                   " oe" + std::to_string(obsEdge[code]) + " L" + std::to_string(cd.legal) + " ok" + std::to_string(cd.ok1) + std::to_string(cd.ok2);
            if (cd.dest >= 0)
                dbg += " occ" + std::to_string(occId[cd.dest]) + " own" + std::to_string(ownStamp[cd.dest] == stamp) + "/" + std::to_string(ownRel[cd.dest]);
            if (cd.dive > -1e9)
                dbg += " dive" + std::to_string(cd.dive).substr(0, 4);
        }
        for (auto const& h : heads)
            dbg += " H" + std::to_string(h.id) + (h.mine ? "m@" : "e@") + std::to_string(h.cell % W) + "," + std::to_string(h.cell / W) + "l" + std::to_string(h.len);
        for (int tc : enemyTails)
            dbg += " T@" + std::to_string(tc % W) + "," + std::to_string(tc / W);
        ct.output_log(dbg);
    }
#endif

    bool const nextToEnemy = is_adjacent_enemy_head(head);
    bool queenAdjacent = false;
    for (auto const& cd : cands)
        if (cd.attack && occId[cd.dest] == enemyQueenId && !enemyQueenDead)
        {
            queenAdjacent = true;
            attackDir = cd.d;
        }
    bool const allIn = ourQueenDead && !enemyQueenDead; // we lose at round 500 unless their queen dies
    // A head-on kills both dragons. While expanding, numbers are what we are
    // building, so only trade up: the enemy queen, a longer enemy, or when we
    // clearly outnumber them.
    bool const evenTrades = !(EXPANSION && expansionPhase);
    bool const wantAttack = attackAvail && !amQueen &&
                            ((queenAdjacent) ||
                             (!isLeader && (role == ROLE_COMBAT || mode == MODE_COMBAT || allIn) &&
                              (evenTrades ? (L <= attackLen + 1 || units > est_enemy_units() + 1 || L <= 4 || allIn)
                                          : (attackLen > L || units > est_enemy_units() + 1 || allIn))));
    int const freeN = std::min(free_steps(), MAX_SPRINT);

    // ---- 0. Sprint into the enemy queen ("one smells blood") -----------------
    if (PAID_REGICIDE && !amQueen && !enemyQueenDead)
        for (auto const& h : heads)
            if (!h.mine && h.id == enemyQueenId)
            {
                int const reach = std::min(REGICIDE_MAX, free_steps() + std::max(0, L - 2));
                std::vector<int> const path = regicide_path(h.cell, reach);
                set_body(body, L);
                if (!path.empty())
                {
                    queue_fact(msg_danger(head, 1), 70, 2);
                    if (EQ_DEATH_DETECT)
                        queue_fact(msg_queen_dead(true), 99, 4); // certain: she moved before us
                    return act_moves(ct, path, "regicide");
                }
            }
    // Snipe: a short dragon that can put its head on an enemy head this turn
    // (free + paid steps) and is no longer than it strikes: a head-on kills
    // both, so it never trades down. Witnesses report the death drops.
    if (SNIPE && !amQueen && !isLeader && L <= SNIPE_MAX_LEN)
    {
        std::vector<HeadInfo const*> targets;
        for (auto const& h : heads)
            if (!h.mine && h.id != enemyQueenId && h.len >= L)
                targets.push_back(&h);
        std::sort(targets.begin(), targets.end(), [](HeadInfo const* a, HeadInfo const* b) { return a->len > b->len; });
        int const reach = std::min(REGICIDE_MAX, free_steps() + std::max(0, L - 2));
        for (auto const* h : targets)
        {
            std::vector<int> const path = regicide_path(h->cell, reach);
            set_body(body, L);
            if (!path.empty())
            {
                queue_fact(msg_danger(h->cell, 1), 70, 2);
                return act_moves(ct, path, "snipe");
            }
        }
    }
    // Pack members: work out the shared prey, and strike a long enemy dragon
    // when its head is within reach (a short dragon for a long one).
    bool const packer = HUNTERS && !amQueen && !isLeader && !isGuard && (isHunter || (ENDGAME_PACKS && ourQueenDead && L <= 6));
    if (packer)
    {
        assign_prey();
        int const preyId = myPrey >= 0 ? preyList[myPrey].id : -1;
        for (auto const& h : heads)
            if (!h.mine && h.id != enemyQueenId && (h.id == preyId || h.len >= std::max(PREY_MIN_LEN, L + 4)))
            {
                int const reach = std::min(REGICIDE_MAX, free_steps() + std::max(0, L - 2));
                std::vector<int> const path = regicide_path(h.cell, reach);
                set_body(body, L);
                if (!path.empty())
                {
                    queue_fact(msg_danger(h.cell, 1), 70, 2);
                    return act_moves(ct, path, "pack-strike");
                }
            }
    }
    if (!amQueen && !enemyQueenDead && !queenAdjacent)
    {
        bool near = false;
        for (auto const& h : heads)
            if (!h.mine && h.id == enemyQueenId && manhattan(h.cell, head) <= std::min(freeN + 1, 3))
                near = true;
        if (near)
        {
            SprintPlan kp;
            std::vector<int> dirs, eatenCells;
            sprint_dfs(body, L, 0, std::min(freeN + 1, 3), freeN, 0, dirs, eatenCells, false, 0, kp);
            set_body(body, L);
            if (kp.kill)
            {
                queue_fact(msg_danger(head, 1), 70, 2);
                if (EQ_DEATH_DETECT)
                    queue_fact(msg_queen_dead(true), 99, 4);
                return act_moves(ct, kp.dirs, "regicide");
            }
        }
    }

    // Short teammates strike enemy heads that have our queen within their
    // reach (one of ours for one attacker; the queen moves first and cannot
    // dodge a sprint).
    if (STALKER_INTERCEPT && !amQueen && !isLeader && !ourQueenDead && L <= 6)
    {
        int qc = -1;
        for (auto const& h : heads)
            if (h.mine && h.id == queenId)
                qc = h.cell;
        auto const q = fleet.find(queenId);
        if (qc < 0 && q != fleet.end() && R - q->second.round <= 2)
            qc = q->second.cell;
        if (qc >= 0)
            for (auto const& h : heads)
            {
                if (h.mine)
                    continue;
                int const el = std::max(h.len, h.estLen);
                if (manhattan(h.cell, qc) > (el + 3) / 4 + std::max(0, el - 2) + 1)
                    continue;
                int const reach = std::min(REGICIDE_MAX, free_steps() + std::max(0, L - 2));
                std::vector<int> const path = regicide_path(h.cell, reach);
                set_body(body, L);
                if (!path.empty())
                {
                    queue_fact(msg_danger(h.cell, 1), 75, 2);
                    return act_moves(ct, path, "intercept");
                }
            }
    }
    // The queen: every single step ends inside some enemy's reach. Sprint out
    // with free steps, paying segments if needed (length is cheaper than her).
    if (QUEEN_PAID_ESCAPE && QUEEN_HARD_THREAT && QUEEN_THREAT_MAP && amQueen && anyLegal)
    {
        double bestSingle = 1e18;
        for (auto const& cd : cands)
            if (cd.legal && !cd.blind && cd.dest >= 0)
                bestSingle = std::min(bestSingle, queen_threat_pen(cd.dest));
        if (bestSingle >= 0.5 * HARD_THREAT_PEN)
        {
            SprintPlan ep;
            std::vector<int> dirs, eatenCells;
            int const steps = std::min(4, free_steps() + std::max(0, L - 2));
            if (steps >= 2)
                sprint_dfs(body, L, 0, steps, free_steps(), 0, dirs, eatenCells, false, 0, ep);
            set_body(body, L);
            if (!ep.dirs.empty() && ep.value > -0.5 * HARD_THREAT_PEN)
            {
                int el = 0;
                std::vector<int> const endBody = simulate_steps(body, L, ep.dirs, el);
                bool const ok = !endBody.empty() && queen_can_survive(endBody, el) &&
                                !(QUEEN_LOOP_SAFE && !loop_reachable(endBody, el));
                set_body(body, L);
                if (ok)
                    return act_moves(ct, ep.dirs, "q-escape");
            }
        }
    }

    // ---- 1. Death is certain: survival split (sections 3, 12) --------------
    if (!anyLegal)
    {
        // Boxed in by our own body: split so that the blocking segment becomes
        // the child's tail. The child moves later this round, which frees that
        // cell, and the front part keeps as many segments as possible.
        if (static_cast<int>(body.size()) >= L)
        {
            int bestKeep = -1;
            for (int d = 0; d < 4; d++)
            {
                int const n = cross(head, d);
                if (n < 0)
                    continue;
                for (int i = 2; i <= L - 2; i++)
                    if (body[i] == n && i > bestKeep)
                        bestKeep = i;
            }
            if (bestKeep >= 2 && ct.can_split(L - bestKeep) && (!amQueen || bestKeep >= L - 2 || bestKeep >= 4 || L < 6))
                return act_split(ct, L - bestKeep, "unwind-split");
        }
        // Stalling only helps if something around the head will move away:
        // another dragon, or our own last two segments (they leave as the child).
        bool willClear = false;
        for (int d = 0; d < 4; d++)
        {
            int const n = cross(head, d);
            if (n < 0)
                continue;
            if (otherRel[n])
                willClear = true;
            for (int i = std::max(0, static_cast<int>(body.size()) - 2); i < static_cast<int>(body.size()); i++)
                if (body[i] == n && static_cast<int>(body.size()) >= L)
                    willClear = true;
        }
        if (amQueen && willClear && L >= 4 && ct.can_split(2))
        {
            // Splitting is not a move: the queen keeps its head, survives this
            // turn and keeps all but 2 segments (the child takes the tail).
            queue_fact(msg_danger(head, nextToEnemy ? 1 : 2), 80, 3);
            return act_split(ct, 2, "queen-stall");
        }
        if (attackAvail && !isLeader && L < 6)
            return act_move(ct, attackDir, "last-attack");
        if (L >= 4 && ct.can_split(L - 2))
        {
            queue_fact(msg_danger(head, nextToEnemy ? 1 : 2), 80, 3);
            return act_split(ct, L - 2, "save-split");
        }
        if (attackAvail)
            return act_move(ct, attackDir, "last-attack");
        // Die without taking a teammate along: never into a friendly head
        // (least of all the queen's); kelp, bodies or our own neck are harmless.
        int deathDir = -1, deathRank = 99;
        for (int d = 0; d < 4; d++)
        {
            int const n = cross(head, d);
            int rank = 2;
            if (n >= 0 && vis[n] && occId[n] >= 0 && occHead[n] && occMine[n])
                rank = occId[n] == queenId ? 9 : 8;
            else if (n == -3 || (n >= 0 && !vis[n]))
                rank = 0; // unknown far side: might even survive
            else if (n >= 0 && occId[n] >= 0 && !occMine[n])
                rank = 1; // enemy body
            if (rank < deathRank)
            {
                deathRank = rank;
                deathDir = d;
            }
        }
        return act_move(ct, deathDir >= 0 ? deathDir : facing, "doomed");
    }
    if (!anySafe && !diving && (freeN >= 2 || L >= 5))
    {
        SprintPlan ep;
        std::vector<int> dirs, eatenCells;
        sprint_dfs(body, L, 0, std::min(freeN + (L >= 5 ? 1 : 0), 3), freeN, 0, dirs, eatenCells, false, 0, ep);
        set_body(body, L);
        bool escOk = ep.kill || ep.value > (amQueen && QUEEN_THREAT_MAP ? -1e6 : QUEEN_EXIT_GUARD ? -0.5 * QUEEN_EXIT_PEN : -1e17);
        if (escOk && amQueen && QUEEN_LOOP_SAFE && !ep.kill && !ep.dirs.empty())
        {
            int el = 0;
            std::vector<int> const endBody = simulate_steps(body, L, ep.dirs, el);
            if (!endBody.empty() && !loop_reachable(endBody, el))
                escOk = false; // an escape into a pocket only delays it
            set_body(body, L);
        }
        if (escOk)
            return act_moves(ct, ep.dirs, ep.kill ? "regicide" : "escape");
    }
    if (!anySafe && !diving && !amQueen && L >= 4 && ct.can_split(L - 2) && child_can_escape(L - 2))
    {
        // Trapped but a pearl is one step away: eat it first (compensation),
        // the survival split is still available next turn.
        bool anyBlind = false, pearlFirst = false;
        for (auto const& cd : cands)
        {
            anyBlind |= cd.blind;
            pearlFirst |= cd.legal && cd.eat;
        }
        if (!anyBlind && !pearlFirst)
        {
            queue_fact(msg_danger(head, nextToEnemy ? 1 : 2), 80, 3);
            return act_split(ct, L - 2, "trap-split");
        }
    }

    // Recycle: boxed in for good (every move leaves less room than our own
    // length) with a teammate close by. The drop is the same either way;
    // dying now, next to the teammate, means it actually gets eaten.
    if (RECYCLE && !anySafe && !diving && !amQueen && !isLeader && L >= 3 && body.size() >= 2)
    {
        bool boxed = true, pearlFirst = false;
        for (auto const& cd : cands)
        {
            if (!cd.legal)
                continue;
            if (cd.blind || cd.ok1 || cd.area >= L)
                boxed = false;
            pearlFirst |= cd.eat;
        }
        bool mateNear = false;
        for (auto const& h : heads)
            if (h.mine && h.id != me)
                for (int i = 0; i < L && i < static_cast<int>(body.size()); i++)
                    if (manhattan(h.cell, body[i]) <= RECYCLE_MATE_DIST)
                        mateNear = true;
        if (boxed && !pearlFirst && mateNear)
            for (int d = 0; d < 4; d++)
                if (nb(head, d) == body[1])
                {
                    queue_fact(msg_danger(head, 2), 60, 1);
                    return act_move(ct, d, "recycle");
                }
    }

    // ---- 2. Head-on attack (sections 15, 16) ------------------------------
    if (wantAttack)
    {
        queue_fact(msg_danger(head, 1), 70, 2);
        return act_move(ct, attackDir, "attack");
    }

    // ---- Target ----------------------------------------------------------
    std::vector<PearlCand> const pearls = gather_pearls();
    int target = -1;
    int portalDir = -1;
    char const* why = "explore";
    int pi = choose_pearl(pearls);
    // Commitment: switching pearls every other turn wastes the moves made so
    // far (in a maze the two pearls are often in different corridors).
    if (TARGET_COMMIT && lastPearl >= 0 && (!amQueen || QUEEN_COMMIT))
    {
        int prevIdx = -1;
        for (int k = 0; k < static_cast<int>(pearls.size()); k++)
            if (pearls[k].cell == lastPearl)
                prevIdx = k;
        if (prevIdx >= 0 && prevIdx != pi && distHead[lastPearl] < INF)
        {
            int const dPrev = distHead[lastPearl];
            int const dNew = pi >= 0 ? distHead[pearls[pi].cell] : INF;
            bool const clearlyBetter = pi >= 0 && dNew + COMMIT_MARGIN <= dPrev && dNew * 10 <= dPrev * 7;
            if (!clearlyBetter)
                pi = prevIdx;
        }
    }
    if (pi >= 0)
    {
        target = pearls[pi].cell;
        claimTarget = target;
        claimEta = distHead[target];
        why = "pearl";
    }
    if (QUEEN_EVADE && QUEEN_HARD_THREAT && amQueen && target >= 0 && (qThreat[target] < INF || qMargin[target] <= 1))
    {
        target = -1;
        claimTarget = -1;
        why = "evade";
    }

    // Combat dragons hunt enemies, preferring the ones near our leaders. When
    // we clearly outnumber them, small dragons also hunt the long enemies.
    bool const outnumber = units > distinctEnemies + 3 && distinctEnemies > 0;
    bool const hunter = !isLeader && ((mode == MODE_COMBAT && role == ROLE_COMBAT) || (outnumber && L <= 5));
    if (hunter && (target < 0 || distHead[target] > 4))
    {
        int best = -1, bestD = 16;
        for (auto const& e : enemyReps)
        {
            if (R - e.round > 3)
                continue;
            if (!(mode == MODE_COMBAT && role == ROLE_COMBAT) && e.len < 6)
                continue;
            int dd = dist_to(distHead, e.cell);
            for (auto const& [id, s] : fleet)
                if (s.leader && R - s.round <= 10 && manhattan(s.cell, e.cell) <= 6)
                    dd -= 6;
            if (dd < bestD)
            {
                bestD = dd;
                best = e.cell;
            }
        }
        if (best >= 0)
        {
            target = best;
            why = "hunt";
        }
    }

    // The enemy queen decides the game: chase her when she is close, always
    // for combat dragons, and with everyone once our own queen is gone.
    if (!amQueen && !enemyQueenDead && (!isLeader || allIn))
    {
        int qc = -1, qround = -1;
        for (auto const& e : enemyReps)
            if (e.id == enemyQueenId && R - e.round <= 4 && e.round > qround)
            {
                qc = e.cell;
                qround = e.round;
            }
        if (qc >= 0)
        {
            int const dq = dist_to(distHead, qc);
            int const range = allIn ? 60 : HUNT_QUEEN_RANGE;
            if (dq <= range && (role == ROLE_COMBAT || hunter || allIn || dq <= 6))
            {
                target = qc;
                why = "hunt-queen";
            }
        }
    }

    // Farming endgame (section 13): feeders walk to our queen (or, without
    // her, to the nearest leader).
    int feedLeader = -1, feedId = -1;
    // When feeding starts: open maps turn numbers into length from
    // CONSOL_ROUND; behind on queen length we start earlier (sooner still on
    // open maps); otherwise only the last FEED_WINDOW rounds.
    TieState const ts = TIE_TRACK ? tie_state() : TieState{};
    bool const behindQ = TIE_TRACK && !ourQueenDead && !enemyQueenDead && ts.ourQ >= 0 && ts.theirQ >= 0 && ts.ourQ <= ts.theirQ;
    int feedStart = consolidate ? CONSOL_ROUND : 500 - FEED_WINDOW;
    if (behindQ)
        feedStart = std::min(feedStart, openMap ? FEED_BEHIND_OPEN : FEED_BEHIND_CONGESTED);
    bool const earlyFeed = R < 500 - FEED_WINDOW; // guards, hunters and defenders keep their jobs until the last rounds
    bool const feedPhase = !isLeader && R >= feedStart && mode != MODE_COMBAT && localThreat == 0 &&
                           !(earlyFeed && (isGuard || isHunter || isDefender)) && !(FEED_ONLY_IF_CONTEST && enemyQueenDead && !ourQueenDead);
    if (feedPhase)
    {
        int bestD = INF, longestId = -1, longestLen = -1;
        // Giant: on open maps a share of the feeders grows it too (it wins
        // the longest-dragon tiebreak if the queens end up dead or tied).
        int const gid = GIANT && consolidate && !ourQueenDead && (me % GIANT_SHARE == 0) ? giant_id() : -1;
        if (gid >= 0 && gid != me)
        {
            for (auto const& h : heads)
                if (h.mine && h.id == gid)
                {
                    feedLeader = h.cell;
                    feedId = gid;
                }
            auto const g = fleet.find(gid);
            if (feedLeader < 0 && g != fleet.end() && R - g->second.round <= 30)
            {
                feedLeader = g->second.cell;
                feedId = gid;
            }
        }
        if (ourQueenDead && R >= 500 - LATE_LONGEST_ONLY)
            for (auto const& [id, s] : fleet)
                if (s.leader && R - s.round <= 5 && s.len > longestLen)
                {
                    longestLen = s.len;
                    longestId = id;
                }
        for (auto const& [id, s] : fleet)
        {
            if (feedId >= 0)
                break; // feeding the giant
            bool const ok = ourQueenDead ? s.leader && (longestId < 0 || id == longestId) : id == queenId;
            if (ok && R - s.round <= (consolidate ? 30 : 5) && manhattan(s.cell, head) < bestD)
            {
                bestD = manhattan(s.cell, head);
                feedLeader = s.cell;
                feedId = id;
            }
        }
        for (auto const& h : heads)
            if (h.mine && !(gid >= 0 && feedId == gid) && (ourQueenDead ? (fleet.count(h.id) && fleet[h.id].leader && (longestId < 0 || h.id == longestId)) : h.id == queenId))
            {
                feedLeader = h.cell;
                feedId = h.id;
            }
        // Open map, nowhere to find her: the longest leader in view grows instead.
        if (consolidate && feedLeader < 0)
        {
            int bestLen = 0;
            for (auto const& h : heads)
                if (h.mine && h.id != me && fleet.count(h.id) && fleet[h.id].leader && h.len > bestLen)
                {
                    bestLen = h.len;
                    feedLeader = h.cell;
                    feedId = h.id;
                }
        }
        // Queue: a swarm of feeders walls her in, so with enough of them
        // around her already the rest wait their turn further out.
        int crowd = 0;
        if (feedLeader >= 0)
            for (auto const& h : heads)
                if (h.mine && h.id != me && h.id != feedId && manhattan(h.cell, feedLeader) <= 5)
                    crowd++;
        bool const waitTurn = feedLeader >= 0 && crowd >= FEED_CROWD && manhattan(head, feedLeader) > 4;
        if (feedLeader >= 0 && !waitTurn && (target < 0 || distHead[target] > 6))
        {
            target = feedLeader;
            why = "feed";
        }
    }

    // Packs: go for the shared prey; the first one there waits a little for
    // a mate so the pack arrives together (alone, it just goes in).
    if (packer && !feedPhase && (L >= HUNTER_LEN || ourQueenDead) && myPrey >= 0 &&
        (target < 0 || std::string(why) != "pearl" || distHead[target] > 2))
    {
        Prey const& pr = preyList[myPrey];
        if (dist_to(distHead, pr.cell) < INF)
        {
            target = pr.cell;
            why = pr.queen ? "hunter" : "pack";
            bool preyInView = false;
            for (auto const& h : heads)
                if (!h.mine && h.id == pr.id)
                    preyInView = true;
            if (PACK_REGROUP > 0 && myPackSize >= 2 && !preyInView && manhattan(head, pr.cell) <= PACK_REGROUP &&
                mates_near(pr.cell, PACK_REGROUP + 3) == 0)
            {
                target = -1;
                why = "regroup";
            }
        }
    }

    // Guards: intercept enemies closing on the queen, otherwise screen her
    // from a few tiles out (crowding her walls her in).
    int guardQ = -1;
    if (isGuard && !feedPhase)
    {
        int qCellG = -1;
        for (auto const& h : heads)
            if (h.mine && h.id == queenId)
                qCellG = h.cell;
        auto const q = fleet.find(queenId);
        if (qCellG < 0 && q != fleet.end() && R - q->second.round <= (isScreen ? 60 : 3))
            qCellG = q->second.cell;
        guardQ = qCellG;
        if (qCellG >= 0)
        {
            int threat = -1, threatD = INF;
            for (auto const& h : heads)
                if (!h.mine && manhattan(h.cell, qCellG) <= GUARD_INTERCEPT && manhattan(h.cell, qCellG) < threatD)
                {
                    threat = h.cell;
                    threatD = manhattan(h.cell, qCellG);
                }
            if (threat >= 0)
            {
                // A head-on kills both: one guard for one attacker near the queen.
                int const reach = std::min(REGICIDE_MAX, free_steps() + std::max(0, L - 2));
                std::vector<int> const path = regicide_path(threat, reach);
                set_body(body, L);
                if (!path.empty())
                {
                    queue_fact(msg_danger(threat, 1), 75, 2);
                    return act_moves(ct, path, "intercept");
                }
                target = threat;
                why = "intercept";
            }
            else if (isScreen && screen_post(qCellG) >= 0)
            {
                // Stand watch out toward the enemy: attackers are seen (and
                // reported to her) before they are within striking reach.
                int const post = screen_post(qCellG);
                if (manhattan(head, post) > 1)
                {
                    target = post;
                    why = "screen";
                }
                else if (target >= 0 && distHead[target] > 3)
                    target = -1;
            }
            else if (manhattan(head, qCellG) > GUARD_RING && distHead[qCellG] < INF)
            {
                target = qCellG;
                why = "guard";
            }
            else if (target >= 0 && distHead[target] > 4)
                target = -1; // stay around here; no long trips while on duty
        }
    }

    if (guardQ >= 0 && target < 0)
        why = "guard"; // idle on station: no exploring away from the queen

    // Once the enemy queen is dead ours only has to stay alive: no long
    // trips for pearls, the guards come to her.
    if (GUARDS && amQueen && enemyQueenDead && target >= 0 && distHead[target] > 3)
        target = -1;

    // Bunker: head for the chosen box, then circle it.
    // Tie bunker: late in the game with both queens short and theirs no
    // longer than ours, queen length is a tie at best and the next tiebreak
    // is the longest dragon, so ours just circles at her length (<= 3).
    bool tieBunker = false;
    if (TIE_BUNKER && BUNKER && amQueen && !enemyQueenDead && !ourQueenDead && R >= TIE_BUNKER_ROUND && L <= 3)
    {
        auto const it = enemyLenMem.find(enemyQueenId);
        tieBunker = TIE_FORCE || (it != enemyLenMem.end() && it->second.exact && R - it->second.round <= TIE_SEEN_ROUNDS && it->second.len <= L);
    }
    bool const bunkerMode = BUNKER && amQueen && (enemyQueenDead || tieBunker) && !ourQueenDead;
    int bunkerDir = -1;
    bool inBox = false;
    if (bunkerMode)
    {
        std::array<int, 4> bx{};
        if (bunkerBox < 0 || !box_cells(bunkerBox, bx) || !box_usable(bx))
            bunkerBox = choose_bunker();
        if (bunkerBox >= 0 && box_cells(bunkerBox, bx))
        {
            inBox = std::find(bx.begin(), bx.end(), head) != bx.end();
            why = "bunker";
            target = -1;
            if (inBox && L <= 3)
            {
                for (int d = 0; d < 4; d++)
                {
                    int const n = cross(head, d);
                    if (n < 0 || std::find(bx.begin(), bx.end(), n) == bx.end())
                        continue;
                    if (std::find(body.begin(), body.end(), n) != body.end())
                        continue; // the tail still blocks the cell it leaves
                    if (vis[n] && occId[n] >= 0)
                        continue;
                    if (pearl_at(n) && L >= 3)
                    {
                        bunkerBox = -1; // a pearl in the loop would jam it: pick another box next turn
                        continue;
                    }
                    bunkerDir = d;
                }
            }
            else if (!inBox)
            {
                int bd = INF;
                for (int x : bx)
                    if (distHead[x] < bd)
                    {
                        bd = distHead[x];
                        target = x;
                    }
            }
        }
    }

    // Portals: whole regions (and most of the pearls on some maps) lie behind
    // portals whose far end nobody has seen. Scouts open them early: one
    // crossing teaches everyone the pair, and paths then use it.
    // Only worth the risk when the portals lead somewhere we cannot walk to:
    // our reachable area (unexplored edges count as open) is a small part of
    // the map.
    int reachable = 0;
    for (int c = 0; c < N; c++)
        reachable += distHead[c] < INF;
    bool const boxedIn = reachable * 100 < SCOUT_REACH_PCT * N;
    bool const scout = PORTAL_SCOUTS && (boxedIn || PORTAL_ALWAYS) && !amQueen && !isLeader && L <= 12 && (hunterSlot || role == ROLE_PORTAL) &&
                       (why == std::string("pearl") || why == std::string("explore"));
    if (!amQueen && !isLeader && L <= 12 && (scout || (target < 0 && (boxedIn || role == ROLE_PORTAL))) &&
        !(isGuard && why != std::string("explore")))
    {
        int pd = -1;
        int const pg = choose_portal_goal(pd);
        bool take = pg >= 0 && (target < 0 || std::string(why) != "pearl" || distHead[pg] + SCOUT_PEARL_MARGIN <= distHead[target]);
        if (!PORTAL_SCOUTS)
            take = take && target < 0 && role == ROLE_PORTAL;
        if (take)
        {
            target = pg;
            portalDir = pd;
            why = "portal";
        }
    }
    if (AGGRO_EXPANSION && target < 0 && hunterSlot && expansionPhase && !isLeader && !isGuard)
    {
        // Take the middle early: idle hunter-group dragons head for the enemy
        // side (the mirror image of our queen's start), past the centre.
        int const qt = enemyQueenDead ? -1 : enemy_queen_target();
        if (qt >= 0 && distHead[qt] < INF)
        {
            target = qt;
            why = "push";
        }
    }
    if (isDefender && !feedPhase && std::string(why) != "intercept" &&
        (target < 0 || halfMargin(target) <= 0 || distHead[target] > 10))
    {
        int const dg = choose_camp_goal(true);
        if (dg >= 0)
        {
            target = dg;
            why = "defend";
        }
    }
    if (target < 0 && !(GUARDS && amQueen && enemyQueenDead) && !(amQueen && QUEEN_AVOID_UNKNOWN) && std::string(why) != "guard" &&
        std::string(why) != "regroup" && std::string(why) != "evade")
    {
        target = choose_explore_goal();
        // Nothing unseen left to look at: wait by a spawn tile instead of
        // revisiting old ground (pearls appear there, not on the way).
        if (IDLE_CAMP && !amQueen && !isGuard && (target < 0 || seenRound[target] >= 0))
        {
            int const cg = choose_camp_goal();
            if (cg >= 0)
            {
                target = cg;
                why = "camp";
            }
        }
    }

    // Stalled: no step closer to this pearl for STALL_ROUNDS turns (it is
    // behind kelp we keep running into): leave it to others for a while.
    if (std::string(why) == "pearl" && target >= 0)
    {
        int const dNow = distHead[target];
        if (target != stallTarget)
        {
            stallTarget = target;
            stallBest = dNow;
            stallRound = R;
        }
        else if (dNow < stallBest)
        {
            stallBest = dNow;
            stallRound = R;
        }
        else if (STALL_ROUNDS > 0 && R - stallRound >= STALL_ROUNDS)
        {
            skipPearl[target] = R + STALL_SKIP;
            stallTarget = -1;
        }
        lastPearl = target;
    }
    else
        lastPearl = -1;

    // ---- 3. Feeding sacrifice (section 13) ----------------------------------
    if (feedPhase && feedLeader >= 0 && L >= 3 && units > (earlyFeed ? CONSOL_MIN_UNITS : 2) && feedId != me)
    {
        bool seenNear = false;
        for (auto const& h : heads)
            if (h.mine && h.id == feedId && cheb(h.cell, head) <= 4)
                seenNear = true;
        for (auto const& [lid, ls] : fleet)
        {
            if (lid != feedId || (!seenNear && (R - ls.round > 2 || cheb(ls.cell, head) > 4)))
                continue;
            // Squeeze into the neck: the body turns into pearls next to the leader.
            if (body.size() >= 2)
                for (int d = 0; d < 4; d++)
                    if (nb(head, d) == body[1])
                        return act_move(ct, d, "feed-leader");
        }
    }

    // ---- 4. Splits (sections 2, 8, 14) ---------------------------------------
    bool const calm = !nextToEnemy;
    // Runners: on big maps a share of the fleet stays long enough for two
    // free steps a turn, covers distance, and buds off children of 3+.
    bool const isRunner = (RUNNERS && !amQueen && !isLeader && !isGuard && !isHunter && role == ROLE_EXPLORER && N >= RUNNER_MIN_CELLS &&
                           R < EXP_END) ||
                          isDefender; // defenders stay medium length too: a 2-long blocker is easily stepped round
    int const growChild = isRunner ? L - RUNNER_KEEP : L / 2;
    if (amQueen && bunkerMode && !tieBunker && !sealedNoSplit && L >= 4 && (inBox || qThreat[head] == INF))
    {
        int const child = L - 2; // keep 2: one stray pearl then still leaves the loop a free cell
        if (ct.can_split(child))
            return act_split(ct, child, "bunker-trim");
    }
    if (amQueen && !bunkerMode && !sealedNoSplit)
    {
        if (EXPANSION)
        {
            // Numbers first: the queen splits too (head-ons kill whatever the
            // length, so a short queen is no easier to kill and harder to trap).
            bool crowded = false;
            for (auto const& h : heads)
                if (manhattan(h.cell, head) <= 3)
                    crowded = true;
            if (calm && !consolidate && queenSplits && anySafe && !crowded && L >= 4 && room_for_more() && ct.can_split(L / 2) && child_can_escape(L / 2) &&
                split_keeps_loop(L / 2))
                return act_split(ct, L / 2, "queen-split");
        }
        else if (calm && R < EARLY_SPLIT_ROUNDS && units < QUEEN_SEED_UNITS && L >= 5 && ct.can_split(2) && child_can_escape(2) &&
                 split_keeps_loop(2))
            return act_split(ct, 2, "queen-seed");
    }
    else if (calm && !consolidate && (!isHunter || (FAST_OPEN && expansionPhase) || (HUNTER_SPLIT_LEN > 0 && L >= HUNTER_SPLIT_LEN)) &&
             L >= (isRunner ? RUNNER_SPLIT_LEN : EARLY_SPLIT_MIN_LEN) && (EXPANSION ? R < EXP_END && !isLeader : R < EARLY_SPLIT_ROUNDS) &&
             room_for_more() && ct.can_split(growChild) && child_can_escape(growChild))
        return act_split(ct, growChild, "grow-fleet");

    // Lane split: the tail sits among spawn tiles nobody else holds, so the
    // child is born right where the pearls keep coming.
    if (LANE_SPLIT && !consolidate && calm && !amQueen && !isLeader && !isGuard && (!isHunter || expansionPhase) && L >= 4 &&
        (!isRunner || L - 2 >= RUNNER_KEEP) && units < std::min(unitLimit - 2, std::max(2, N / LANE_DENSITY)) &&
        static_cast<int>(body.size()) >= L && ct.can_split(2))
    {
        int const tail = body.back(), tx = tail % W, ty = tail / W;
        int tiles = 0;
        for (int dy = -3; dy <= 3; dy++)
            for (int dx = -3 + std::abs(dy); dx <= 3 - std::abs(dy); dx++)
                if (nextSpawn[cell_of((tx + dx + W) % W, (ty + dy + H) % H)] >= 0)
                    tiles++;
        bool mateNear = false;
        for (auto const& h : heads)
            if (h.mine && h.id != me && manhattan(h.cell, tail) <= 4)
                mateNear = true;
        if (tiles >= LANE_TILES && !mateNear && child_can_escape(2))
            return act_split(ct, 2, "lane-split");
    }

    if (calm && !consolidate && !isLeader && !isHunter && L >= 4 && (!isRunner || L - 2 >= RUNNER_KEEP) && pi >= 0 && room_for_more() && ct.can_split(2) &&
        static_cast<int>(body.size()) >= L)
    {
        int const tail = body.back();
        std::vector<int> child{tail, body[L - 2]};
        wstamp++;
        for (int i = 0; i < L - 2; i++)
            wallStamp[body[i]] = wstamp;
        set_body(child, 2);
        plan_bfs(tail, distTmp);
        wstamp++;
        set_body(body, L);
        int const pc = pearls[pi].cell;
        int const dt = distTmp[pc], dh = distHead[pc];
        if (dt <= PEARL_BEHIND_MAX && dt + PEARL_BEHIND_GAIN <= dh && child_can_escape(2))
            return act_split(ct, 2, "pearl-split");
    }

    if (calm && !consolidate && transitioned && !isLeader && !isHunter && mode == MODE_PRESERVE && L >= PRESERVE_SPLIT_LEN && room_for_more() &&
        ct.can_split(L / 2) && child_can_escape(L / 2))
        return act_split(ct, L / 2, "keep-fleet");

#ifdef FLEET_DEBUG
    {
        std::string dbg = std::string("target ") + why + " " + (target >= 0 ? std::to_string(target % W) + "," + std::to_string(target / W) : "-") +
                          " d" + (target >= 0 ? std::to_string(distHead[target]) : "-") + " pearls";
        for (auto const& p : pearls)
            dbg += " " + std::to_string(p.cell % W) + "," + std::to_string(p.cell / W);
        ct.output_log(dbg);
    }
#endif
    // ---- 5. Best move ------------------------------------------------------
    std::vector<int> teamCells;
    for (int c = 0; c < N; c++)
        if (vis[c] && occId[c] >= 0 && occId[c] != me && occMine[c])
            teamCells.push_back(c);

    // Teammates must not wall the queen in: measure her free space with our
    // body where it is now and where each move would put it.
    int qHead = -1, qLen = 0, qNeed = 0, qBase = 0;
    if (QUEEN_ROOM && !amQueen)
        for (auto const& h : heads)
            if (h.mine && h.id == queenId && manhattan(h.cell, head) <= 5)
            {
                qHead = h.cell;
                auto const q = fleet.find(queenId);
                qLen = std::max(h.len, q != fleet.end() && R - q->second.round <= 3 ? q->second.len : 0);
                qNeed = 2 * qLen + 4;
                set_body(body, L);
                ignoreContested = true;
                qBase = flood(qHead, -1, qNeed + 4).area;
                ignoreContested = false;
            }

    // Give the queen room: where is she (vision, else sonar status)?
    int qCell = -1;
    if (QUEEN_CLEAR > 0 && !amQueen && !ourQueenDead && std::string(why) != "feed")
    {
        for (auto const& h : heads)
            if (h.mine && h.id == queenId)
                qCell = h.cell;
        auto const q = fleet.find(queenId);
        if (qCell < 0 && q != fleet.end() && R - q->second.round <= 2)
            qCell = q->second.cell;
        if (qCell >= 0 && manhattan(qCell, head) <= QUEEN_CLEAR + 4)
            queen_dist_bfs(qCell, QUEEN_CLEAR + 2);
        else
            qCell = -1;
    }

    if (bunkerDir >= 0 && cands[bunkerDir].legal)
    {
        cands[bunkerDir].ok1 = cands[bunkerDir].ok2 = true; // the box loop never traps a queen of length <= 3
        cands[bunkerDir].surv = true;
    }
    int bestD = -1;
    double bestScore = -1e18;
    for (auto& cd : cands)
    {
        if (!cd.legal)
            continue;
        double s = cd.d == bunkerDir ? 900000.0 : 0.0;
        if (qCell >= 0 && !cd.blind && cd.dest >= 0)
        {
            // Teammates crowding the queen (her children start right behind
            // her) seal her into corridors; getting out of her way is free.
            int const dq = qDist[cd.dest], dnow = qDist[head];
            if (dq <= QUEEN_CLEAR && dq <= dnow)
                s -= QUEEN_CLEAR_PEN * (QUEEN_CLEAR + 1 - dq) * (open_sides(cd.dest) <= 2 ? 2.0 : 1.0);
        }
        if (guardQ >= 0 && !cd.blind && cd.dest >= 0 && std::string(why) != "intercept")
        {
            int const dg = manhattan(guardQ, cd.dest);
            if (dg < GUARD_MIN && dg <= manhattan(guardQ, head))
                s -= GUARD_MIN_PEN * (GUARD_MIN - dg);
        }
        if (qHead >= 0 && !cd.blind && !cd.nb1.empty() && std::string(why) != "feed")
        {
            set_body(cd.nb1, L + (cd.eat ? 1 : 0));
            ignoreContested = true;
            int const qa = flood(qHead, -1, qNeed + 4).area;
            ignoreContested = false;
            if (qa < qNeed && qa < qBase)
                s -= QUEEN_ROOM_PEN * (1.0 + static_cast<double>(qBase - qa) / qNeed);
        }
        if (cd.blind)
        {
            // Unknown far side: only for small, expendable dragons (section 5).
            bool const wanted = role == ROLE_PORTAL || role == ROLE_EXPLORER;
            if (isLeader)
                s = anySafe ? -1e7 : -5e5; // better than a certain trap
            else if (portalDir == cd.d && target == head)
                s = 5000;
            else
                s = wanted && L <= 6 ? -500 : -4000;
            if (!anySafe)
                s += 3000;
        }
        else
        {
            // Risk is judged against its reward. A trap with nothing gained is
            // an avoidable death; a trap that pays a pearl is acceptable,
            // cheapest when a survival split can save all but 2 segments.
            int const lenAfter = L + (cd.eat ? 1 : 0);
            bool const canSave = lenAfter >= 4 && units < unitLimit;
            // No pearl compensates for losing the queen.
            if (!amQueen && !cd.ok1 && cd.dive >= DIVE_MIN_GAIN)
                s += 2500.0 * cd.dive - 1500.0; // a dead end whose pearls pay for the split
            else if (QUEEN_SURV_RANK && amQueen && !anySafe && !cd.ok2)
                s -= cd.surv ? 5e5 : (QUEEN_HARD_THREAT ? QUEEN_TRAP_PEN : 1e6);
            else if (!cd.ok2)
                s -= (cd.eat && !amQueen && !(cd.dive > -1e9 && cd.dive < 0)) ? (canSave ? 2500.0 : 2500.0 + 900.0 * lenAfter)
                     : (amQueen && QUEEN_HARD_THREAT) ? QUEEN_TRAP_PEN : 1e6;
            else if (!cd.ok1)
                s -= (cd.eat && !amQueen) ? 1500.0 : amQueen ? 2e5 : 2e4;
            s += std::min(cd.area, cap) * (amQueen ? 60.0 : 15.0);
            if (amQueen && L >= QUEEN_LONG_LEN && cd.dest >= 0 && open_sides(cd.dest) <= 2)
                s -= QUEEN_CORRIDOR_PEN; // a long queen cannot turn round in a corridor: one blocker ahead kills her
            if (cd.eat)
                s += isLeader ? 6000 : 3000;
            if (target >= 0)
            {
                set_body(cd.nb1, L + (cd.eat ? 1 : 0));
                plan_bfs(cd.dest, distTmp);
                int dt = dist_to(distTmp, target);
                if (portalDir >= 0 && target != head && cd.dest == target)
                    dt = 0;
                cd.dt = dt;
                s -= 150.0 * std::min(dt, 200);
            }
            for (auto const& h : heads)
            {
                int const reach = (!h.mine && isLeader) ? enemy_reach(h) : 1;
                if (manhattan(h.cell, cd.dest) > reach)
                    continue;
                if (!h.mine && amQueen && QUEEN_THREAT_MAP)
                    continue; // the threat map below covers it
                if (!h.mine)
                    s -= amQueen ? 3e6
                         : isLeader ? (L >= h.len + 2 ? 200000 : 500000)
                                    : (mode == MODE_COMBAT && role == ROLE_COMBAT ? 500 : THREAT_PEN);
                else
                    s -= isLeader || amQueen ? 4000 : TEAM_ADJ_PEN;
            }
            if (amQueen && QUEEN_THREAT_MAP)
                s -= queen_threat_pen(cd.dest);
            if (cd.noLoop && cd.d != bunkerDir)
                s -= QUEEN_LOOP_PEN;
            if (amQueen && queenSealed && cd.eat && L + 1 > sealedCells - 1)
                s -= 2e6; // eating would fill the sealed pocket: no free cell left to move into
            if (amQueen && !vis[cd.dest])
                s -= 5e5; // a portal whose far side we cannot see: only as a last resort
            if (amQueen && QUEEN_AVOID_PORTAL)
            {
                std::uint8_t const et = edgeType[edge_code(head, cd.d)];
                if (et != E_OPEN && et != E_KELP && et != E_UNK)
                    s -= 1e6; // crossing a portal: never by choice
                for (int k = 0; k < 4; k++)
                {
                    std::uint8_t const t2 = edgeType[edge_code(cd.dest, k)];
                    if (t2 != E_OPEN && t2 != E_KELP && t2 != E_UNK)
                        s -= 150000; // next to a portal mouth
                }
            }
            if (amQueen && QUEEN_AVOID_UNKNOWN)
            {
                for (int k = 0; k < 4; k++)
                    if (edgeType[edge_code(cd.dest, k)] == E_UNK)
                        s -= 30000;
                if (seenRound[cd.dest] < 0)
                    s -= 200000;
            }
            if (!amQueen && !vis[cd.dest])
            {
                // Blind portal exit: we cannot see who stands there. Never risk
                // landing on the queen, who moves first and may be right there.
                s -= 3000;
                auto const q = fleet.find(queenId);
                if (q != fleet.end() && R - q->second.round <= 3 && manhattan(q->second.cell, cd.dest) <= 2 + (R - q->second.round))
                    s -= 2e6;
            }
            if (amQueen) // stay clear of where the fleet saw enemies recently, even out of view
                for (auto const& e : enemyReps)
                {
                    if (R - e.round > 8)
                        continue;
                    int const dd = manhattan(e.cell, cd.dest);
                    if (dd <= 7)
                        s -= 4000.0 * (8 - dd);
                }
            if (amQueen) // keep the queen well away from enemy heads, not just out of reach
                for (auto const& h : heads)
                    if (!h.mine)
                    {
                        int const dd = manhattan(h.cell, cd.dest);
                        if (dd <= 5)
                            s -= 25000.0 * (6 - dd);
                    }
            if (isLeader) // an enemy that splits sends a new head out of its tail
                for (int tc : enemyTails)
                    if (manhattan(tc, cd.dest) <= 1)
                        s -= amQueen ? 400000 : 100000;
            for (auto const& dg : dangers)
                if (R - dg.round <= 30 && manhattan(dg.cell, cd.dest) <= 3)
                    s -= isLeader ? 3000 : 300;
            // Confinement: when we are safe, prefer moves that squeeze a nearby
            // enemy's free space (pin it against kelp and bodies).
            if (cd.ok2 && cd.area >= 2 * L + 4)
                for (auto const& h : heads)
                {
                    if (h.mine || manhattan(h.cell, cd.dest) > 4)
                        continue;
                    int const ecap = 2 * h.len + 8;
                    set_body(cd.nb1, L + (cd.eat ? 1 : 0));
                    ignoreContested = true;
                    FloodRes const ef = flood(h.cell, -1, ecap);
                    ignoreContested = false;
                    int const earea = ef.area + (ef.frontier ? ecap : 0);
                    double const mult = h.id == enemyQueenId ? 3.0 : 1.0;
                    if (earea <= h.len + 1)
                        s += 3500 * mult;
                    else
                        s += mult * 1500.0 * std::max(0.0, 1.0 - static_cast<double>(earea) / ecap);
                }
            if (!isLeader && std::string(why) != "feed")
                for (int tc : teamCells)
                    s -= 150.0 / (1 + manhattan(tc, cd.dest));
            if (PORTAL_ROW && cd.dest >= 0 && cd.dest != nb(head, cd.d))
            {
                // Through a portal: a teammate whose head is at (or next to) the
                // far end may be stepping the other way this very round, and
                // the two heads would meet. The lower id goes first.
                auto clash = [&](int id, int cell) {
                    int const dd = manhattan(cell, cd.dest);
                    return dd == 0 || (dd == 1 && id < me);
                };
                bool hit = false;
                for (auto const& h : heads)
                    if (h.mine && h.id != me && clash(h.id, h.cell))
                        hit = true;
                for (auto const& [id, st] : fleet)
                    if (id != me && R - st.round <= 1 && clash(id, st.cell))
                        hit = true;
                if (hit)
                    s -= PORTAL_ROW_PEN;
            }
            if (QUEEN_EXIT_GUARD && !amQueen && !cd.nb1.empty()) // feeders too: they can give their pearls from 4 cells away
                for (auto const& h : heads)
                    if (h.mine && h.id == queenId && manhattan(h.cell, cd.dest) <= 2)
                    {
                        std::vector<int> nowBody(body.begin(), body.begin() + std::min<int>(body.size(), L));
                        std::vector<int> after(cd.nb1.begin(), cd.nb1.begin() + std::min<int>(cd.nb1.size(), L + (cd.eat ? 1 : 0)));
                        int const before = queen_exits(h.cell, nowBody), now = queen_exits(h.cell, after);
                        if (now < before && now < 2)
                            s -= QUEEN_EXIT_PEN; // never take one of the queen's last ways out
                    }
            if (!amQueen && (std::string(why) != "feed" || consolidate))
                for (auto const& h : heads)
                    if (h.mine && h.id == queenId)
                    {
                        // Do not box the queen in: her own body is mostly out of
                        // our view, so keep clear of her head instead.
                        int const dq = manhattan(h.cell, cd.dest);
                        if (dq <= 2)
                            s -= QUEEN_SPACE_PEN;
                        else if (dq == 3)
                            s -= QUEEN_SPACE_PEN / 3.5;
                    }
            if (cd.d == facing)
                s += 3;
        }
        cd.score = s;
        if (s > bestScore)
        {
            bestScore = s;
            bestD = cd.d;
        }
    }
    set_body(body, L);
    if (bestD < 0)
        bestD = facing;
    // The way to the pearl only leads into a dead end that does not pay:
    // stop circling outside and let the matching pick another pearl.
    if (pi >= 0 && target == pearls[pi].cell && distHead[target] < INF)
    {
        bool closer = false, closerOk = false;
        for (auto const& cd : cands)
            if (cd.legal && !cd.blind && cd.dt < distHead[target])
            {
                closer = true;
                closerOk |= cd.ok1 || cd.dive >= DIVE_MIN_GAIN;
            }
        if (closer && !closerOk)
            skipPearl[target] = R + SKIP_PEARL_ROUNDS;
    }

    // Free steps: keep going along the chosen direction while it pays (more
    // pearls, more progress) and the turn still ends somewhere safe.
    Cand const& c1 = cands[bestD];
    if (freeN >= 2 && c1.legal && !c1.blind && c1.ok2 && target >= 0 && portalDir < 0 && !c1.nb1.empty())
    {
        stamp++; // distances to the goal ignore our own body
        plan_bfs(target, distGoal);
        set_body(body, L);
        int const g0 = distGoal[head];
        bool const useGoal = g0 < INF;
        int const nl = L + (c1.eat ? 1 : 0);
        int const cap1 = std::min(N, 3 * nl + 24);
        double const v1 = (c1.eat ? 3000.0 : 0.0) + std::min(c1.area, cap1) * 15.0 - end_threat(c1.dest) +
                          (useGoal && distGoal[c1.dest] < INF ? 150.0 * (g0 - distGoal[c1.dest]) : 0.0);
        SprintPlan sp;
        std::vector<int> dirs{bestD}, eatenCells;
        if (c1.eat)
            eatenCells.push_back(c1.dest);
        sprint_dfs(c1.nb1, nl, 1, freeN, freeN, c1.eat ? 1 : 0, dirs, eatenCells, useGoal, g0, sp);
        set_body(body, L);
        bool sprintOk = sp.kill || (sp.value > v1 + 300 && sp.dirs.size() >= 2);
        if (sprintOk && amQueen && !sp.kill)
        {
            int el = 0;
            std::vector<int> const endBody = simulate_steps(body, L, sp.dirs, el);
            sprintOk = !endBody.empty() && queen_can_survive(endBody, el) &&
                       !(QUEEN_LOOP_SAFE && !loop_reachable(endBody, el));
            set_body(body, L);
        }
        if (sprintOk)
            return act_moves(ct, sp.dirs, sp.kill ? "regicide" : why);
    }
    act_move(ct, bestD, why);
}

// ---------------------------------------------------------------------------
// Sonar output (section 4): four messages a turn, N/E/S/W.
// ---------------------------------------------------------------------------
// Direction of a sonar ray that runs straight to our queen (same row or
// column, the shorter way round), or -1.
int queen_sonar_dir()
{
    if (me == queenId || ourQueenDead || body.empty())
        return -1;
    auto const q = fleet.find(queenId);
    if (q == fleet.end() || R - q->second.round > 3)
        return -1;
    int const h = body[0], qc = q->second.cell;
    int const hx = h % W, hy = h / W, qx = qc % W, qy = qc / W;
    if (hy == qy && hx != qx)
        return ((qx - hx + W) % W) <= ((hx - qx + W) % W) ? 1 : 3;
    if (hx == qx && hy != qy)
        return ((qy - hy + H) % H) <= ((hy - qy + H) % H) ? 2 : 0;
    return -1;
}

void send_sonars(Controller& ct)
{
    std::vector<std::uint64_t> out;
    out.push_back(msg_status());
    if (QUEEN_POS_RELAY && amQueen)
        out.push_back(out[0]); // two directions a turn: every teammate in line hears where she is
    if (claimTarget >= 0)
        out.push_back(msg_claim(claimTarget, claimEta));

    std::sort(facts.begin(), facts.end(), [](Fact const& a, Fact const& b) { return a.prio > b.prio; });
    for (auto& f : facts)
    {
        if (out.size() >= 4)
            break;
        if (f.prio < 30 && !pearlQ.empty() && out.size() == 3)
            break; // leave room for pearl news
        out.push_back(f.msg);
        f.sends--;
    }
    std::erase_if(facts, [](Fact const& f) { return f.sends <= 0; });

    if (out.size() < 4 && !pearlQ.empty())
    {
        std::sort(pearlQ.begin(), pearlQ.end(), [](PearlEntry const& a, PearlEntry const& b) { return a.prio > b.prio; });
        BitW b;
        int const take = std::min<int>(2, static_cast<int>(pearlQ.size()));
        b.put(take - 1, 1);
        for (int i = 0; i < take; i++)
        {
            b.put(pearlQ[i].kind, 2);
            b.put(pearlQ[i].cell, 12);
            b.put(pearlQ[i].round, 9);
        }
        pearlQ.erase(pearlQ.begin(), pearlQ.begin() + take);
        out.push_back(pack(T_PEARL, b.v));
    }

    // Gossip what we already know, so late arrivals catch up.
    for (int attempt = 0; attempt < 12 && out.size() < 4; attempt++)
    {
        int const pick = static_cast<int>(rng() % 3);
        if (pick == 0 && !kelpList.empty())
        {
            BitW b;
            int const n = std::min<int>(3, static_cast<int>(kelpList.size()));
            b.put(n, 2);
            for (int i = 0; i < n; i++)
                b.put(kelpList[rng() % kelpList.size()], 13);
            out.push_back(pack(T_KELP, b.v));
        }
        else if (pick == 1 && !portalPairs.empty())
        {
            auto const& pp = portalPairs[rng() % portalPairs.size()];
            out.push_back(msg_portal(pp.first, pp.second));
        }
        else if (pick == 2)
        {
            // a known upcoming or present pearl
            int found = -1;
            for (int tries = 0; tries < 24 && found < 0; tries++)
            {
                int const c = static_cast<int>(rng() % static_cast<unsigned>(N));
                if (pearlState[c] == 1 || (nextSpawn[c] >= R && !nextEst[c] && nextSpawn[c] - R <= 30))
                    found = c;
            }
            if (found < 0)
                continue;
            BitW b;
            b.put(0, 1);
            bool const present = pearlState[found] == 1;
            b.put(present ? 1 : 0, 2);
            b.put(found, 12);
            b.put(present ? pearlRound[found] : nextSpawn[found], 9);
            out.push_back(pack(T_PEARL, b.v));
        }
    }

    int const offset = (R + me) & 3;
    std::array<int, 4> dirOf{};
    for (int i = 0; i < 4; i++)
        dirOf[i] = (i + offset) & 3;
    // Aim the most urgent enemy news at the queen when she is on our row or
    // column (a ping stops at the first dragon it meets, so nearer is better).
    int const qd = AIM_REPORTS ? queen_sonar_dir() : -1;
    if (qd >= 0)
    {
        int best = -1;
        for (int i = 0; i < static_cast<int>(out.size()); i++)
        {
            int type;
            std::uint64_t payload;
            if (unpack(out[i], type, payload) && (type == T_ENEMY || type == T_DANGER))
            {
                best = i;
                break; // facts are already in priority order
            }
        }
        if (best >= 0)
            for (int i = 0; i < 4; i++)
                if (dirOf[i] == qd)
                {
                    if (i >= static_cast<int>(out.size()))
                        out.resize(i + 1, out[0]);
                    std::swap(out[i], out[best]);
                    break;
                }
    }
    for (int i = 0; i < static_cast<int>(out.size()) && i < 4; i++)
        ct.send_sonar(dir_of(dirOf[i]), out[i]);
}

// ---------------------------------------------------------------------------
// Fallback: any move that is not immediately fatal.
// ---------------------------------------------------------------------------
void fallback_move(Controller& ct)
{
    Position const here = ct.get_position();
    Tile const* t = ct.get_tile(here);
    for (int d = 0; d < 4; d++)
    {
        if (t && !t->get_edge(dir_of(d)).is_passable())
            continue;
        Tile const* ahead = ct.get_tile(here.add_dir(dir_of(d)));
        if (ahead && ahead->get_dragon())
            continue;
        ct.make_move(dir_of(d));
        return;
    }
    ct.make_move(ct.get_dir());
}

void init_world(Controller& ct, Game& game)
{
    auto const [w, h] = game.get_map_size();
    W = w;
    H = h;
    N = W * H;
    me = ct.get_id();
    myTeam = ct.get_team().value;
    unitLimit = game.get_unit_limit();
    rng.seed(static_cast<std::uint32_t>(me) * 7919u + 17u);
    // Map files list team A's dragons first, so A usually owns id 0; vision and
    // sonar correct this as soon as either queen is seen or heard.
    queenId = me <= 1 ? me : (myTeam == Team::A ? 0 : 1);
    enemyQueenId = 1 - queenId;
    amQueen = me == queenId;
    role = role_for(me);

    edgeType.assign(2 * N, E_UNK);
    obsEdge.assign(2 * N, E_UNK);
    edgePid.assign(2 * N, -1);
    edgePartner.assign(2 * N, -1);
    seenRound.assign(N, -1);
    obsNext.assign(N, -1);
    nextSpawn.assign(N, -1);
    nextEst.assign(N, 0);
    pearlState.assign(N, 0);
    dropRound.assign(N, -1);
    pearlRound.assign(N, -1);
    gapLo.assign(N, 0);
    gapHi.assign(N, 0);
    vis.assign(N, 0);
    occId.assign(N, -1);
    occMine.assign(N, 0);
    occHead.assign(N, 0);
    occDir.assign(N, 0);
    otherRel.assign(N, 0);
    contested.assign(N, 0);
    ownStamp.assign(N, 0);
    ownRel.assign(N, 0);
    wallStamp.assign(N, 0);
    visStamp.assign(N, 0);
    distHead.assign(N, INF);
    distTmp.assign(N, INF);
    distGoal.assign(N, INF);
    pathStamp.assign(N, 0);
    pathTime.assign(N, 0);
    skipPearl.assign(N, 0);
    planSteps.assign(N, 0);
    qThreat.assign(N, INF);
    qThreatVis.assign(N, INF);
    qThreatCnt.assign(N, 0);
    qMargin.assign(N, INF);
    qDist.assign(N, INF);
    thStamp.assign(N, 0);
    thDist.assign(N, 0);
    thQ.reserve(N);
    bfsQ.reserve(N);
    bfsT.reserve(N);
}

} // namespace

int main()
{
    auto [ct, game] = unswbc::init();
    init_world(ct, game);

    while (unswbc::update(ct, game))
    {
        bool acted = false;
        try
        {
            R = game.get_round_num();
            L = ct.get_length();
            units = ct.get_unit_count();

            read_vision(ct);
            update_body(ct);
            read_sonar(ct);
            update_unobserved();
            resolve_symmetry();
            prune_knowledge();
            detect_teammate_deaths();
            record_enemies();
            fleet[me] = {L, body[0], R, isLeader};
            compute_fleet_state();

            decide(ct);
            acted = true;
            send_sonars(ct);

            static char const* const roleName[] = {"col", "exp", "prt", "cmb"};
            static char const* const modeName[] = {"nrm", "farm", "keep", "war"};
            std::string ind = std::string(amQueen ? "QUEEN " : isLeader ? "LEAD " : "") + roleName[role] + " " + modeName[mode] + " " + note +
                              " L" + std::to_string(L);
            if (symKnown >= 0)
                ind += " s" + std::to_string(symKnown);
            if (isScreen || isGuard)
                ind += isScreen ? " SCR" : " GRD";
            ct.set_indicator_string(ind);
        }
        catch (...)
        {
            if (!acted)
                fallback_move(ct);
        }
        unswbc::end_turn();
    }
}
